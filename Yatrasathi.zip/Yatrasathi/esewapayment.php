<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    redirectTo('login.php');
}

$bookingId = (int) ($_GET['booking_id'] ?? 0);
$status = trim($_GET['status'] ?? '');
$dataParam = $_GET['data'] ?? '';
$isDemoMode = isDemoPaymentMode();

if ($bookingId <= 0) {
    exit('Invalid eSewa callback.');
}

if ($status !== 'success') {
    redirectTo('payment.php?booking_id=' . $bookingId . '&error=' . urlencode('eSewa payment was cancelled or not completed.'));
}

$reference = '';
$decoded = [];
if ($dataParam !== '') {
    $decoded = json_decode(base64_decode($dataParam), true);
}

$booking = fetchBookingWithBus($conn, $bookingId, (int) $_SESSION['user_id']);
if (!$booking) {
    exit('Booking not found.');
}

if (isDepartureExpired($booking['departure_date'] ?? '', $booking['departure_time'] ?? '')) {
    redirectTo('payment.php?booking_id=' . $bookingId . '&error=' . urlencode('This bus has already departed, so eSewa payment is no longer available.'));
}

if ($isDemoMode) {
    if (($booking['payment_status'] ?? '') === 'Paid') {
        redirectTo('payment_success.php?booking_id=' . $bookingId);
    }

    $reference = 'ESEWA-DEMO-' . strtoupper(bin2hex(random_bytes(3)));
    markBookingPaid($conn, $bookingId, (int) $_SESSION['user_id'], 'eSewa Demo', $reference);
    redirectTo('payment_success.php?booking_id=' . $bookingId . '&message=' . urlencode('Demo eSewa payment completed.'));
}

if (!empty($decoded['status']) && strtoupper((string) $decoded['status']) === 'COMPLETE') {
    $expectedAmount = number_format(calculateBookingTotal($booking), 2, '.', '');
    $returnedAmount = number_format((float) ($decoded['total_amount'] ?? 0), 2, '.', '');
    $expectedTransaction = $booking['ticket_number'] ?: ('YTBOOKING-' . $booking['id']);
    $returnedTransaction = (string) ($decoded['transaction_uuid'] ?? '');

    if ($returnedAmount !== $expectedAmount || $returnedTransaction !== $expectedTransaction) {
        redirectTo('payment.php?booking_id=' . $bookingId . '&error=' . urlencode('eSewa payment details did not match this booking.'));
    }

    $reference = (string) ($decoded['transaction_code'] ?? $decoded['transaction_uuid'] ?? 'eSewa');
    markBookingPaid($conn, $bookingId, (int) $_SESSION['user_id'], 'eSewa', $reference);
    redirectTo('payment_success.php?booking_id=' . $bookingId);
}

redirectTo('payment.php?booking_id=' . $bookingId . '&error=' . urlencode('Unable to verify eSewa payment. Please try again.'));
