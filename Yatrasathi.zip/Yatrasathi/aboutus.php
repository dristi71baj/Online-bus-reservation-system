<?php
require_once 'config.php';
$userLoggedIn = isset($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us | YatraSathi</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Roboto',sans-serif;background:#eef4ff;color:#15304c;line-height:1.6}a{text-decoration:none}.navbar{display:flex;justify-content:space-between;align-items:center;gap:18px;padding:18px 24px;background:#0f4c81;color:#fff;flex-wrap:wrap}.brand{font-size:1.4rem;font-weight:700}.nav-links{display:flex;flex-wrap:wrap;gap:14px}.nav-links a{color:#fff;font-weight:500}.hero{padding:56px 20px;background:linear-gradient(135deg,rgba(15,76,129,.92),rgba(31,111,214,.82)),url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee') center/cover no-repeat;color:#fff}.hero-inner{max-width:1120px;margin:0 auto}.hero h1{font-size:clamp(2rem,5vw,3.5rem);margin-bottom:12px}.hero p{max-width:700px;color:#dcecff}.section{padding:54px 20px}.section-inner{max-width:1120px;margin:0 auto}.grid{display:grid;gap:18px}.grid-2{grid-template-columns:1.1fr .9fr}.grid-3{grid-template-columns:repeat(auto-fit,minmax(250px,1fr))}.card{background:#fff;padding:24px;border-radius:20px;box-shadow:0 10px 28px rgba(21,57,93,.08)}.card h3,.card h4{color:#0f4c81;margin-bottom:10px}.story{height:100%;display:flex;flex-direction:column;justify-content:center}.cover{width:100%;height:100%;min-height:320px;object-fit:cover;border-radius:20px;box-shadow:0 10px 28px rgba(21,57,93,.08)}.stat{background:linear-gradient(180deg,#ffffff,#f3f8ff)}.stat strong{display:block;font-size:1.8rem;color:#1f6fd6;margin-bottom:6px}footer{padding:20px;background:#0f4c81;color:#fff;text-align:center}@media (max-width: 860px){.grid-2{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="navbar"><div class="brand">YatraSathi</div><div class="nav-links"><a href="index.php">Home</a><a href="aboutus.php">About</a><a href="contact.php">Contact</a><?php if ($userLoggedIn): ?><a href="my_bookings.php">My Bookings</a><a href="logout.php">Logout</a><?php else: ?><a href="login.php">Login</a><a href="register.php">Register</a><?php endif; ?></div></div>
<section class="hero"><div class="hero-inner"><h1>Building simpler bus travel across Nepal.</h1><p>YatraSathi connects travelers, routes, booking management, and online payments into one easier reservation experience.</p></div></section>
<section class="section"><div class="section-inner grid grid-2"><div class="card story"><h3>Who we are</h3><p>YatraSathi is a digital bus reservation platform designed to make route discovery, seat booking, payment, and ticket management easier for travelers and operators.</p><p>We focus on a practical travel flow: search by place, compare buses, confirm seats, pay online, and keep every booking visible later from one page.</p><h3 style="margin-top:18px">What we improve</h3><p>We reduce confusion around route availability, manual booking records, ticket tracking, and payment follow-up by keeping those steps connected inside a responsive web experience.</p></div><img class="cover" src="https://images.unsplash.com/photo-1517760444937-f6397edcbbcd" alt="Bus travel"></div></section>
<section class="section" style="padding-top:0"><div class="section-inner"><div class="grid grid-3"><div class="card stat"><strong>Smart Search</strong><p>Travelers can find routes with live place suggestions and cleaner search results.</p></div><div class="card stat"><strong>Faster Booking</strong><p>Passenger details, seat selection, payment, and ticket number generation all happen in one connected flow.</p></div><div class="card stat"><strong>Better Tracking</strong><p>Users and admins can see ticket history, paid bookings, and cancelled bookings more clearly.</p></div></div></div></section>
<section class="section" style="padding-top:0"><div class="section-inner"><div class="grid grid-3"><div class="card"><h4>Mission</h4><p>Make bus travel in Nepal more transparent, organized, and mobile friendly.</p></div><div class="card"><h4>Vision</h4><p>Create a reliable reservation platform where passengers and operators both have clearer ticket visibility.</p></div><div class="card"><h4>Promise</h4><p>Provide practical booking tools that save time before the trip and reduce confusion after the trip is booked.</p></div></div></div></section>
<footer>&copy; <?= date('Y') ?> YatraSathi. All rights reserved.</footer>
</body>
</html>
