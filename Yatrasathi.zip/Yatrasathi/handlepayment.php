<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    redirectTo('login.php');
}

if (!isset($_GET['pidx']) || !isset($_GET['purchase_order_id'])) {
    exit('Invalid payment request.');
}

$query = http_build_query([
    'purchase_order_id' => (int) $_GET['purchase_order_id'],
    'pidx' => trim((string) $_GET['pidx']),
    'status' => trim((string) ($_GET['status'] ?? '')),
    'transaction_id' => trim((string) ($_GET['transaction_id'] ?? '')),
]);

redirectTo('khaltiverify.php?' . $query);
