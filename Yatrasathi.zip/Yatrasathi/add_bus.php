<?php
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    redirectTo('login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $busName = trim($_POST['bus_name'] ?? '');
    $busType = trim($_POST['bus_type'] ?? 'Standard');
    $source = trim($_POST['source'] ?? '');
    $destination = trim($_POST['destination'] ?? '');
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $price = (float) ($_POST['price'] ?? 0);
    $seats = (int) ($_POST['seats'] ?? 0);

    $stmt = $conn->prepare(
        "INSERT INTO buses (bus_name, bus_type, source, destination, departure_date, departure_time, price, seats_available, total_seats, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())"
    );
    $stmt->bind_param('ssssssdii', $busName, $busType, $source, $destination, $date, $time, $price, $seats, $seats);
    $stmt->execute();
    $stmt->close();

header("Location: admin_dashboard.php");
exit();}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Bus | YatraSathi</title>
<style>
body{margin:0;font-family:Arial,sans-serif;background:#eef4ff;color:#17324c;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:16px}.box{width:min(100%,520px);background:#fff;border-radius:20px;padding:26px;box-shadow:0 10px 28px rgba(21,57,93,.08)}h1{margin-bottom:16px}label{display:block;margin:12px 0 6px;font-weight:700}input,select,button{width:100%;padding:12px 14px;border-radius:12px;border:1px solid #cad8e8}button{margin-top:18px;background:#1f6fd6;color:#fff;border:none;font-weight:700;cursor:pointer}.links{display:flex;gap:14px;margin-top:16px}.links a{color:#1f6fd6;text-decoration:none;font-weight:700}
</style>
</head>
<body>
<div class="box">
    <h1>Add New Bus</h1>
    <form method="POST">
        <label for="bus_name">Bus Name</label>
        <input id="bus_name" name="bus_name" required>

        <label for="bus_type">Bus Type</label>
        <select id="bus_type" name="bus_type" required>
            <option value="AC Deluxe">AC Deluxe</option>
            <option value="Deluxe">Deluxe</option>
            <option value="Tourist">Tourist</option>
            <option value="Sleeper">Sleeper</option>
            <option value="Standard">Standard</option>
        </select>

        <label for="source">From</label>
        <input id="source" name="source" required>

        <label for="destination">To</label>
        <input id="destination" name="destination" required>

        <label for="date">Departure Date</label>
        <input id="date" type="date" name="date" required>

        <label for="time">Departure Time</label>
        <input id="time" type="time" name="time" required>

        <label for="price">Price</label>
        <input id="price" type="number" step="0.01" min="0" name="price" required>

        <label for="seats">Total Seats</label>
        <input id="seats" type="number" min="1" name="seats" required>

        <button type="submit">Save Bus</button>
    </form>
    <div class="links">
        <a href="admin_dashboard.php">Back to Dashboard</a>
        <a href="index.php">View Site</a>
    </div>
</div>
<script>
window.history.pushState(null, "", window.location.href);

window.onpopstate = function () {
    window.location.href = "admin_dashboard.php";
};
</script>
</body>
</html>
