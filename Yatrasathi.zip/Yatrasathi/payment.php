﻿<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    redirectTo('login.php');
}

$bookingId = (int) ($_GET['booking_id'] ?? 0);
if ($bookingId <= 0) {
    exit('Invalid payment request.');
}

$booking = fetchBookingWithBus($conn, $bookingId, (int) $_SESSION['user_id']);
if (!$booking) {
    exit('Booking not found.');
}

$user = fetchUser($conn, (int) $_SESSION['user_id']);
$passengerPhone = getPassengerPhone($booking);
$isExpired = isDepartureExpired($booking['departure_date'] ?? '', $booking['departure_time'] ?? '');
$paymentMessage = trim((string) ($_GET['message'] ?? ''));
$paymentError = trim((string) ($_GET['error'] ?? ''));
$totalAmount = calculateBookingTotal($booking);
$paymentConfig = getPaymentConfig();
$isDemoMode = isDemoPaymentMode();
$transactionUuid = $booking['ticket_number'] ?: ('YTBOOKING-' . $booking['id']);
$esewaAmount = number_format($totalAmount, 2, '.', '');
$message = 'total_amount=' . $esewaAmount . ',transaction_uuid=' . $transactionUuid . ',product_code=' . $paymentConfig['esewa']['product_code'];
$signature = createEsewaSignature($message, $paymentConfig['esewa']['secret_key']);
$backUrl = getSmoothBackUrl('my_bookings.php');

$availableMethods = [];

if (!empty($paymentConfig['esewa']['enabled'])) {
    $availableMethods[] = [
        'key' => 'esewa',
        'name' => 'eSewa',
        'description' => 'Demo payment via eSewa gateway.',
        'buttonClass' => 'esewa',
        'mode' => 'Demo',
    
    ];
}

if (isPaymentConfigured('khalti')) {
    $availableMethods[] = [
        'key' => 'khalti',
        'name' => 'Khalti',
        'description' => 'Demo payment via Khalti gateway.',
        'buttonClass' => 'khalti',
        'mode' => 'Demo',
        
    ];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payment | YatraSathi</title>
<style>
html{scroll-behavior:smooth}
body{margin:0;font-family:Arial,sans-serif;background:linear-gradient(180deg,#eef4ff 0%,#f8fbff 100%);color:#17324c}
.page{max-width:1080px;margin:0 auto;padding:28px 18px 40px}
.grid{display:grid;grid-template-columns:1.1fr 1fr;gap:20px}
.panel{background:#fff;border-radius:20px;padding:22px;box-shadow:0 12px 30px rgba(17,55,95,.08);animation:fadeUp .35s ease}
.notice{padding:14px 16px;border-radius:14px;margin-bottom:16px}
.warn{background:#fff7e6;color:#8a5a00;border:1px solid #f2d28c}
.paid{background:#ecfff0;color:#116329;border:1px solid #bfe8c6}
.info{background:#edf4ff;color:#1f4f8a;border:1px solid #c9ddfb}
.error{background:#fff1f1;color:#b42318;border:1px solid #f7c2c2}
.meta{color:#5d7287}
.booking-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:18px}
.booking-item{padding:14px;border-radius:14px;background:#f8fbff;border:1px solid #dce7f4}
.booking-item strong{display:block;margin-bottom:6px;color:#0f4c81}
button{width:100%;padding:14px;border:none;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer}
.esewa{background:#60bb46;color:#fff}
.khalti{background:#5c2d91;color:#fff}
.actions{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px}
.actions a{text-decoration:none;color:#1f6fd6;font-weight:700}
.method-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-top:12px}
.method-card{border:1px solid #d7e3f2;border-radius:16px;padding:14px;background:#fbfdff;display:flex;flex-direction:column;gap:10px}
.method-card h3{margin:0;font-size:1.06rem;color:#0f4c81}
.mode{display:inline-block;padding:4px 9px;border-radius:999px;background:#edf4ff;color:#1f6fd6;font-size:.8rem;font-weight:700}
.method-card p{margin:0;color:#5d7287;font-size:.94rem}
.method-card form{margin-top:auto}
.method-card form.is-loading button{opacity:.75;cursor:progress}
.loading-note{display:none;margin-top:10px;color:#5d7287;font-size:.9rem}
.method-card form.is-loading .loading-note{display:block}
@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
@media (max-width: 860px){.grid{grid-template-columns:1fr}.page{padding:24px 14px 32px}}
@media (max-width: 560px){.booking-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="page">
    <div class="actions">
        <a class="js-back-link" href="<?= htmlspecialchars($backUrl) ?>">Back</a>
        <a href="my_bookings.php">My Bookings</a>
    </div>

    <div class="grid">
        <div class="panel">
            <h1>Booking Payment</h1>
            <?php if ($paymentError !== ''): ?>
                <div class="notice error"><?= htmlspecialchars($paymentError) ?></div>
            <?php elseif ($paymentMessage !== ''): ?>
                <div class="notice info"><?= htmlspecialchars($paymentMessage) ?></div>
            <?php endif; ?>
            <p><strong>Ticket:</strong> <?= htmlspecialchars($booking['ticket_number']) ?></p>
            <p><strong>Bus:</strong> <?= htmlspecialchars($booking['bus_name']) ?></p>
            <p><strong>Route:</strong> <?= htmlspecialchars($booking['source']) ?> to <?= htmlspecialchars($booking['destination']) ?></p>
            <p><strong>Departure:</strong> <?= htmlspecialchars($booking['departure_date']) ?> at <?= htmlspecialchars(formatDepartureTime($booking['departure_time'])) ?></p>
            <p><strong>Passenger:</strong> <?= htmlspecialchars($booking['passenger_name']) ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($passengerPhone) ?></p>
            <p><strong>Seats:</strong> <?= htmlspecialchars($booking['seat_numbers']) ?></p>
            <p><strong>Total:</strong> Rs. <?= number_format($totalAmount, 2) ?></p>
            <p class="meta">User: <?= htmlspecialchars($user['name'] ?? 'Passenger') ?> | Status: <?= htmlspecialchars(formatBookingStatus($booking)) ?> | Payment: <?= htmlspecialchars($booking['payment_status']) ?></p>
            <div class="booking-grid">
                <div class="booking-item">
                    <strong>Passenger details</strong>
                    <?= htmlspecialchars($booking['passenger_name']) ?><br>
                    <?= htmlspecialchars($passengerPhone) ?>
                </div>
                <div class="booking-item">
                    <strong>Selected seats</strong>
                    <?= htmlspecialchars($booking['seat_numbers']) ?>
                </div>
            </div>

            <?php if (($booking['status'] ?? '') === 'Cancelled'): ?>
                <div class="notice warn">This booking has already been cancelled.</div>
            <?php elseif ($isExpired): ?>
                <div class="notice warn">This bus has already departed, so payment is no longer available for this booking.</div>
            <?php elseif (($booking['payment_status'] ?? '') === 'Paid'): ?>
                <div class="notice paid">Payment is already complete for this booking.</div>
            <?php endif; ?>
        </div>

        <div class="panel">
            <h2>Choose payment method</h2>
            <p class="meta" style="margin-bottom:16px"> You can pay directly from Esewa or Khalti.</p>
            <?php if ($isDemoMode): ?>
    
            <?php endif; ?>

            <?php if (($booking['status'] ?? '') !== 'Cancelled' && ($booking['payment_status'] ?? '') !== 'Paid' && !$isExpired): ?>
                <?php if (empty($availableMethods)): ?>
                    <div class="notice warn">No payment method is enabled right now. Please contact support.</div>
                <?php else: ?>
                    <div class="method-grid">
                        <?php foreach ($availableMethods as $method): ?>
                            <div class="method-card">
                                <div>
                                    <h3><?= htmlspecialchars($method['name']) ?></h3>
                                    <span class="mode"><?= htmlspecialchars($method['mode']) ?> Mode</span>
                                </div>
                                <p><?= htmlspecialchars($method['description']) ?></p>

                                <?php if ($method['key'] === 'esewa'): ?>
                                    <form class="payment-submit-form" action="demo_gateway.php" method="GET">
    <input type="hidden" name="booking_id" value="<?= (int) $bookingId ?>">
    <input type="hidden" name="gateway" value="esewa">

    <button class="esewa" type="submit">Pay with eSewa</button>
</form>
                                     <?php if ($isDemoMode): ?>
                                            <input type="hidden" name="booking_id" value="<?= (int) $bookingId ?>">
                                            <input type="hidden" name="status" value="success">
                                            <input type="hidden" name="demo" value="1">
                                        <?php else: ?>
                                            <input type="hidden" name="amount" value="<?= htmlspecialchars($esewaAmount) ?>">
                                            <input type="hidden" name="tax_amount" value="0">
                                            <input type="hidden" name="total_amount" value="<?= htmlspecialchars($esewaAmount) ?>">
                                            <input type="hidden" name="transaction_uuid" value="<?= htmlspecialchars($transactionUuid) ?>">
                                            <input type="hidden" name="product_code" value="<?= htmlspecialchars($paymentConfig['esewa']['product_code']) ?>">
                                            <input type="hidden" name="product_service_charge" value="0">
                                            <input type="hidden" name="product_delivery_charge" value="0">
                                            <input type="hidden" name="success_url" value="<?= htmlspecialchars(getBaseUrl('esewapayment.php?booking_id=' . $bookingId . '&status=success')) ?>">
                                            <input type="hidden" name="failure_url" value="<?= htmlspecialchars(getBaseUrl('esewapayment.php?booking_id=' . $bookingId . '&status=failure')) ?>">
                                            <input type="hidden" name="signed_field_names" value="total_amount,transaction_uuid,product_code">
                                            <input type="hidden" name="signature" value="<?= htmlspecialchars($signature) ?>">
                                        <?php endif; ?>
                                        <div class="loading-note"><?= htmlspecialchars($isDemoMode ? 'Processing demo eSewa payment...' : 'Redirecting to eSewa...') ?></div>
                                    </form>
                                <?php elseif ($method['key'] === 'khalti'): ?>
<form class="payment-submit-form" action="demo_gateway.php" method="GET">
    <input type="hidden" name="booking_id" value="<?= (int) $bookingId ?>">
    <input type="hidden" name="gateway" value="khalti">

    <button class="khalti" type="submit">Pay with Khalti</button>
</form>                                        <input type="hidden" name="booking_id" value="<?= (int) $bookingId ?>">
                                        <div class="loading-note"><?= htmlspecialchars($isDemoMode ? 'Processing demo Khalti payment...' : 'Opening Khalti checkout...') ?></div>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <a href="my_bookings.php">Go back to My Bookings</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
document.querySelectorAll('.js-back-link').forEach((link) => {
    link.addEventListener('click', (event) => {
        if (window.history.length > 1 && document.referrer) {
            event.preventDefault();
            window.history.back();
        }
    });
});

document.querySelectorAll('.payment-submit-form').forEach((form) => {
    form.addEventListener('submit', () => {
        form.classList.add('is-loading');
        const button = form.querySelector('button[type="submit"]');
        const note = form.querySelector('.loading-note');

        if (button) {
            button.disabled = true;
        }

        if (note && form.dataset.loadingText) {
            note.textContent = form.dataset.loadingText;
        }
    });
});
</script>
</body>
</html>
