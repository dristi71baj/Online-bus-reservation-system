<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    redirectTo('login.php');
}

$bookingId = (int) ($_GET['booking_id'] ?? $_POST['booking_id'] ?? 0);

if ($bookingId <= 0) {
    exit('Invalid request');
}

/* ================= FETCH BOOKING FIRST ================= */
$stmt = $conn->prepare(
    "SELECT b.*, bs.bus_name, bs.source, bs.destination, bs.price, bs.departure_date, bs.departure_time
     FROM bookings b
     JOIN buses bs ON bs.id = b.bus_id
     WHERE b.id = ? AND b.user_id = ?
     LIMIT 1"
);
$stmt->bind_param('ii', $bookingId, $_SESSION['user_id']);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    exit('Booking not found');
}

/* ================= PAYMENT METHOD FIX ================= */
$paymentMethod = strtolower(trim($booking['payment_method'] ?? ''));

$isKhalti = str_contains($paymentMethod, 'khalti');
$isEsewa  = str_contains($paymentMethod, 'esewa');

/* fallback */
if (!$isKhalti && !$isEsewa) {
    $isEsewa = true;
}

/* ================= AMOUNT ================= */
$paidAmount = calculateBookingTotal($booking);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Payment Success</title>

<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

<style>
body{
    margin:0;
    font-family:Arial;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
    background: <?= $isKhalti ? 'linear-gradient(180deg,#f4edff,#ffffff)' : 'linear-gradient(180deg,#e9fff0,#ffffff)' ?>;
}

.card{
    width:420px;
    background:#fff;
    border-radius:20px;
    box-shadow:0 20px 50px rgba(0,0,0,0.15);
    padding:25px;
    text-align:center;
    animation:pop .4s ease;
}

@keyframes pop{
    from{transform:scale(.8);opacity:0}
    to{transform:scale(1);opacity:1}
}

/* HEADER */
.header{
    color:#fff;
    padding:15px;
    border-radius:15px;
    font-weight:bold;
    margin-bottom:15px;
    background: <?= $isKhalti ? '#5c2d91' : '#1faa00' ?>;
}

/* AMOUNT */
.amount{
    font-size:24px;
    font-weight:bold;
    margin-top:10px;
    color: <?= $isKhalti ? '#5c2d91' : '#1faa00' ?>;
}

/* ROW */
.row{
    display:flex;
    justify-content:space-between;
    padding:8px 0;
    border-bottom:1px solid #eee;
    font-size:14px;
}

/* BUTTON */
.btn{
    display:block;
    margin-top:15px;
    padding:12px;
    color:#fff;
    text-decoration:none;
    border-radius:12px;
    font-weight:bold;
    background: <?= $isKhalti ? '#5c2d91' : '#1faa00' ?>;
}

/* BADGE */
.badge{
    display:inline-block;
    padding:6px 12px;
    border-radius:999px;
    font-size:12px;
    font-weight:bold;
    margin-bottom:10px;
    color:#fff;
    background: <?= $isKhalti ? '#5c2d91' : '#1faa00' ?>;
}
</style>
</head>

<body>

<div class="card">

    <!-- HEADER -->
    <div class="header">
        ✔ <?= $isKhalti ? 'Khalti Payment Successful' : 'eSewa Payment Successful' ?>
    </div>

    <!-- BADGE -->
    <div class="badge">
        <?= $isKhalti ? 'Khalti Verified' : 'eSewa Verified' ?>
    </div>

    <!-- LOTTIE -->
    <lottie-player 
        src="https://assets2.lottiefiles.com/packages/lf20_jbrw3hcz.json"
        background="transparent"
        speed="1"
        autoplay>
    </lottie-player>

    <div class="amount">
        Rs. <?= number_format($paidAmount, 2) ?>
    </div>

    <div class="row">
        <span>Ticket</span>
        <strong><?= htmlspecialchars($booking['ticket_number']) ?></strong>
    </div>

    <div class="row">
        <span>Route</span>
        <strong><?= htmlspecialchars($booking['source']) ?> → <?= htmlspecialchars($booking['destination']) ?></strong>
    </div>

    <div class="row">
        <span>Bus</span>
        <strong><?= htmlspecialchars($booking['bus_name']) ?></strong>
    </div>

    <div class="row">
        <span>Method</span>
        <strong><?= htmlspecialchars($booking['payment_method']) ?></strong>
    </div>

    <p style="font-size:13px;color:#666;margin-top:10px">
        Redirecting in <span id="count">5</span> seconds...
    </p>

    <a class="btn" href="my_bookings.php">View Booking</a>

</div>

<script>
let sec = 15;
let c = document.getElementById("count");

let timer = setInterval(() => {
    sec--;
    c.innerText = sec;

    if(sec <= 0){
        clearInterval(timer);
        window.location.href = "my_bookings.php";
    }
}, 1000);

/* prevent back */
history.pushState(null, "", location.href);
window.onpopstate = function () {
    window.location.href = "index.php";
};
</script>

</body>
</html>
