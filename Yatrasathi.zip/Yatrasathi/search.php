<?php
require_once 'config.php';

$from = trim($_GET['from'] ?? '');
$to = trim($_GET['to'] ?? '');
$date = trim($_GET['date'] ?? '');
$error = '';
$buses = [];

if ($from === '' || $to === '' || $date === '') {
    $error = 'Please choose from, to, and travel date.';
} else {
    $stmt = $conn->prepare(
        "SELECT * FROM buses
         WHERE (
                LOWER(source) = LOWER(?)
                OR source LIKE CONCAT('%', ?, '%')
               )
           AND (
                LOWER(destination) = LOWER(?)
                OR destination LIKE CONCAT('%', ?, '%')
               )
           AND departure_date = ?
         ORDER BY departure_time ASC"
    );
    $stmt->bind_param('sssss', $from, $from, $to, $to, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        if (!isDepartureExpired($row['departure_date'] ?? '', $row['departure_time'] ?? '')) {
            $buses[] = $row;
        }
    }
    $stmt->close();

    if (empty($buses)) {
        $error = 'No buses found for the selected route and date, or the available departure times have already passed.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Search Results | YatraSathi</title>
<style>
body{margin:0;font-family:Arial,sans-serif;background:#eef4ff;color:#17324c}.page{max-width:1120px;margin:0 auto;padding:28px 20px 42px}.topbar{display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:18px}.topbar a{color:#1f6fd6;text-decoration:none;font-weight:700}.summary{background:#fff;border-radius:18px;padding:18px 20px;box-shadow:0 12px 30px rgba(17,55,95,.08);margin-bottom:20px}.error{background:#fff1f1;color:#b42318;border:1px solid #f7c2c2;padding:14px 16px;border-radius:14px}.list{display:grid;gap:18px}.card{background:#fff;border-radius:22px;padding:20px;box-shadow:0 12px 30px rgba(17,55,95,.08)}.head{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px}.head h3{margin:0;color:#0f4c81}.badge{display:inline-block;padding:7px 11px;border-radius:999px;background:#edf4ff;color:#1f6fd6;font-weight:700;font-size:.86rem}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.label{font-size:.82rem;color:#6b7e92;text-transform:uppercase;letter-spacing:.04em}.value{font-weight:700;color:#17324c}.book-btn{display:inline-flex;align-items:center;justify-content:center;padding:12px 16px;border-radius:12px;background:#1f6fd6;color:#fff;font-weight:700;margin-top:16px}.meta{color:#5d7287;margin-top:10px}@media (max-width: 900px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width: 560px){.grid{grid-template-columns:1fr}.page{padding:22px 14px 32px}}
</style>
</head>
<body>
<div class="page">
    <div class="topbar">
        <div>
            <h1>Available Buses</h1>
            <p>Compare bus type, departure time, seats, and price before booking.</p>
        </div>
        <a href="index.php">Back to Search</a>
    </div>

    <div class="summary">
        <strong><?= htmlspecialchars($from) ?></strong> to <strong><?= htmlspecialchars($to) ?></strong> on <strong><?= htmlspecialchars($date) ?></strong>
    </div>

    <?php if ($error !== ''): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php else: ?>
        <div class="list">
            <?php foreach ($buses as $bus): ?>
                <div class="card">
                    <div class="head">
                        <div>
                            <h3><?= htmlspecialchars($bus['bus_name']) ?></h3>
                            <div class="meta"><?= htmlspecialchars($bus['source']) ?> to <?= htmlspecialchars($bus['destination']) ?></div>
                        </div>
                        <span class="badge"><?= htmlspecialchars($bus['bus_type'] ?: 'Standard') ?></span>
                    </div>
                    <div class="grid">
                        <div><div class="label">Departure Date</div><div class="value"><?= htmlspecialchars($bus['departure_date']) ?></div></div>
                        <div><div class="label">Departure Time</div><div class="value"><?= htmlspecialchars(formatDepartureTime($bus['departure_time'])) ?></div></div>
                        <div><div class="label">Available Seats</div><div class="value"><?= (int) $bus['seats_available'] ?></div></div>
                        <div><div class="label">Price</div><div class="value">Rs. <?= number_format((float) $bus['price'], 2) ?></div></div>
                    </div>
                    <a class="book-btn" href="book.php?bus_id=<?= (int) $bus['id'] ?>">Book This Bus</a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
