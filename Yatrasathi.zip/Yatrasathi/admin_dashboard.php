﻿<?php
require_once 'config.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/* =========================
   STRONG AUTH CHECK
========================= */
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}

/* =========================
   DELETE BUS
========================= */
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = $conn->prepare('DELETE FROM buses WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    header("Location: admin_dashboard.php");
    exit();
}

/* =========================
   DELETE BOOKING
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_booking'])) {
    $bookingId = (int) ($_POST['booking_id'] ?? 0);

    if ($bookingId > 0) {
        $stmt = $conn->prepare('SELECT id, bus_id, seats, status FROM bookings WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $bookingId);
        $stmt->execute();
        $bookingToDelete = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($bookingToDelete) {
            $conn->begin_transaction();

            try {
                if (($bookingToDelete['status'] ?? '') !== 'Cancelled') {
                    $restoreSeats = $conn->prepare('UPDATE buses SET seats_available = seats_available + ? WHERE id = ?');
                    $restoreSeats->bind_param('ii', $bookingToDelete['seats'], $bookingToDelete['bus_id']);
                    $restoreSeats->execute();
                    $restoreSeats->close();
                }

                $deletePayment = $conn->prepare('DELETE FROM payments WHERE booking_id = ?');
                $deletePayment->bind_param('i', $bookingId);
                $deletePayment->execute();
                $deletePayment->close();

                $deleteBooking = $conn->prepare('DELETE FROM bookings WHERE id = ?');
                $deleteBooking->bind_param('i', $bookingId);
                $deleteBooking->execute();
                $deleteBooking->close();

                $conn->commit();
            } catch (Throwable $e) {
                $conn->rollback();
            }
        }
    }

    header("Location: admin_dashboard.php#ticket-bookings");
    exit();
}

/* =========================
   FETCH BUSES
========================= */
$buses = [];
$result = $conn->query('SELECT * FROM buses ORDER BY departure_date ASC, departure_time ASC');
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $buses[] = $row;
    }
}

/* =========================
   FETCH BOOKINGS
========================= */
$bookings = [];
$bookingQuery = $conn->query(
    "SELECT b.*, b.phone AS passenger_phone, u.name AS user_name, u.email,
            bs.bus_name, bs.bus_type, bs.source, bs.destination,
            bs.departure_date, bs.departure_time,
            COALESCE(p.total_amount, b.total_amount, ROUND(COALESCE(bs.price, 0) * COALESCE(b.seats, 0), 2)) AS booking_total_amount,
            COALESCE(p.paid_amount, 0) AS paid_amount,
            COALESCE(p.payment_status, b.payment_status, 'Unpaid') AS payment_row_status
     FROM bookings b
     LEFT JOIN users u ON u.id = b.user_id
     LEFT JOIN buses bs ON bs.id = b.bus_id
     LEFT JOIN payments p ON p.booking_id = b.id
     ORDER BY b.created_at DESC, b.id DESC"
);

if ($bookingQuery) {
    while ($row = $bookingQuery->fetch_assoc()) {
        $bookings[] = $row;
    }
}

$paidCount = count(array_filter($bookings, fn($r) => (($r['payment_row_status'] ?? $r['payment_status'] ?? '') === 'Paid')));
$cancelledCount = count(array_filter($bookings, fn($r) => ($r['status'] ?? '') === 'Cancelled'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard | YatraSathi</title>

<!-- ================= NO CACHE (IMPORTANT) ================= -->
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />

<style>
html{scroll-behavior:smooth}
:root{
    --bg:#edf4fb;
    --bg-accent:#d8e9fb;
    --surface:#ffffff;
    --surface-soft:#f6faff;
    --text:#17324c;
    --muted:#5d7287;
    --primary:#0f4c81;
    --primary-strong:#0b3458;
    --primary-soft:#edf5ff;
    --danger:#b42318;
    --danger-soft:#fff1f1;
    --success:#116329;
    --success-soft:#e9f9ee;
    --warning:#8a5a00;
    --warning-soft:#fff7e6;
    --border:#d8e3ef;
    --shadow:0 18px 40px rgba(18,52,84,.10);
}
*{box-sizing:border-box}
body{
    margin:0;
    font-family:Arial,sans-serif;
    background:
        radial-gradient(circle at top left, rgba(255,255,255,.95), rgba(255,255,255,0) 28%),
        linear-gradient(180deg, var(--bg-accent) 0%, var(--bg) 18%, #f8fbff 100%);
    color:var(--text);
}
.layout{display:grid;grid-template-columns:260px minmax(0,1fr);min-height:100vh}
.sidebar{
    background:linear-gradient(180deg, var(--primary-strong), var(--primary));
    color:#fff;
    padding:28px 18px;
    position:sticky;
    top:0;
    align-self:start;
    min-height:100vh;
}
.sidebar h2{margin:0 0 8px;font-size:1.55rem}
.sidebar p{margin:0 0 22px;color:rgba(255,255,255,.75);line-height:1.5}
.sidebar nav{display:grid;gap:8px}
.sidebar a{
    display:flex;
    align-items:center;
    color:#fff;
    padding:12px 14px;
    border-radius:14px;
    margin-bottom:0;
    text-decoration:none;
    background:rgba(255,255,255,.06);
    border:1px solid rgba(255,255,255,.08);
    transition:.2s ease;
}
.sidebar a:hover{background:rgba(255,255,255,.14);transform:translateY(-1px)}
.main{padding:28px}
.hero{
    display:grid;
    grid-template-columns:minmax(0,1.4fr) minmax(240px,.8fr);
    gap:18px;
    background:linear-gradient(140deg, rgba(11,52,88,.96), rgba(31,111,214,.92));
    border-radius:28px;
    padding:26px;
    color:#fff;
    box-shadow:var(--shadow);
    margin-bottom:20px;
    overflow:hidden;
    position:relative;
}
.hero:before{
    content:"";
    position:absolute;
    inset:auto -60px -80px auto;
    width:220px;
    height:220px;
    background:rgba(255,255,255,.08);
    border-radius:50%;
}
.hero h1{margin:0;font-size:2rem;line-height:1.15}
.hero p{margin:10px 0 0;color:rgba(255,255,255,.82);max-width:640px;line-height:1.6}
.hero-panel{
    background:rgba(255,255,255,.10);
    border:1px solid rgba(255,255,255,.14);
    border-radius:22px;
    padding:18px;
    backdrop-filter:blur(6px);
}
.hero-panel small{display:block;color:rgba(255,255,255,.7);text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px}
.hero-panel strong{display:block;font-size:2rem;margin-bottom:6px}
.hero-panel span{color:rgba(255,255,255,.82);line-height:1.5}
.grid{display:grid;gap:18px}
.stats{grid-template-columns:repeat(auto-fit,minmax(190px,1fr));margin-bottom:20px}
.stat-card,.section-card{
    background:var(--surface);
    border-radius:24px;
    box-shadow:var(--shadow);
    border:1px solid rgba(216,227,239,.7);
}
.stat-card{padding:20px}
.stat-card .eyebrow{color:var(--muted);font-size:.85rem;text-transform:uppercase;letter-spacing:.06em}
.stat-card strong{display:block;font-size:2rem;color:var(--primary);margin:10px 0 4px}
.stat-card span{color:var(--muted)}
.section-nav{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px}
.section-nav a{
    display:inline-flex;
    align-items:center;
    padding:11px 16px;
    border-radius:999px;
    background:rgba(255,255,255,.78);
    color:var(--primary);
    font-weight:700;
    text-decoration:none;
    border:1px solid var(--border);
    box-shadow:0 10px 24px rgba(21,57,93,.06);
}
.stack{display:grid;gap:20px}
.section-card{padding:0;overflow:hidden}
.section-head{
    display:flex;
    justify-content:space-between;
    gap:18px;
    align-items:flex-start;
    flex-wrap:wrap;
    padding:24px 24px 18px;
    border-bottom:1px solid var(--border);
}
.section-title h2{margin:0;font-size:1.45rem}
.section-title p{margin:8px 0 0;color:var(--muted);line-height:1.55;max-width:720px}
.section-bus .section-head{background:linear-gradient(180deg, #f8fbff, #eef6ff)}
.section-ticket .section-head{background:linear-gradient(180deg, #fffdfa, #fff6ec)}
.section-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.summary-chip{
    display:inline-flex;
    align-items:center;
    padding:9px 12px;
    border-radius:999px;
    background:var(--surface);
    color:var(--primary);
    font-weight:700;
    border:1px solid var(--border);
}
.table-wrap{padding:0 18px 18px;overflow:auto}
table{width:100%;border-collapse:separate;border-spacing:0 12px}
thead th{
    color:var(--primary);
    background:transparent;
    font-size:.84rem;
    text-transform:uppercase;
    letter-spacing:.06em;
    padding:0 14px 6px;
    border-bottom:none;
}
tbody tr{background:var(--surface-soft)}
tbody td{
    padding:16px 14px;
    text-align:left;
    vertical-align:top;
    white-space:nowrap;
    border-top:1px solid #e7eef7;
    border-bottom:1px solid #e7eef7;
}
tbody td:first-child{
    border-left:1px solid #e7eef7;
    border-top-left-radius:18px;
    border-bottom-left-radius:18px;
}
tbody td:last-child{
    border-right:1px solid #e7eef7;
    border-top-right-radius:18px;
    border-bottom-right-radius:18px;
}
.ticket-id{font-weight:700;color:var(--primary)}
.subtext{display:block;margin-top:5px;color:var(--muted);font-size:.84rem}
.route-pill{
    display:inline-flex;
    padding:6px 10px;
    border-radius:999px;
    background:#fff;
    border:1px solid var(--border);
    font-weight:700;
}
.btn{
    display:inline-flex;
    justify-content:center;
    align-items:center;
    padding:10px 13px;
    border-radius:12px;
    background:var(--danger-soft);
    color:var(--danger);
    text-decoration:none;
    font-weight:700;
    border:none;
    cursor:pointer;
}
.btn:hover{filter:brightness(.98)}
.add{
    display:inline-flex;
    justify-content:center;
    align-items:center;
    padding:12px 16px;
    border-radius:14px;
    background:linear-gradient(135deg, var(--primary), #1f6fd6);
    color:#fff;
    text-decoration:none;
    font-weight:700;
    box-shadow:0 12px 26px rgba(31,111,214,.24);
}
.badge{display:inline-block;padding:7px 10px;border-radius:999px;font-size:.82rem;font-weight:700}
.paid{background:var(--success-soft);color:var(--success)}
.unpaid{background:var(--warning-soft);color:var(--warning)}
.cancelled{background:var(--danger-soft);color:var(--danger)}
.booked{background:var(--primary-soft);color:#1f6fd6}
.muted{color:var(--muted);font-size:.84rem}
.empty-row td{
    text-align:center;
    color:var(--muted);
    white-space:normal;
}
@media (max-width: 1100px){
    .hero{grid-template-columns:1fr}
}
@media (max-width: 960px){
    .layout{grid-template-columns:1fr}
    .sidebar{
        position:static;
        min-height:auto;
        border-bottom-left-radius:24px;
        border-bottom-right-radius:24px;
    }
    .main{padding:18px}
}
@media (max-width: 760px){
    .hero{padding:22px;border-radius:24px}
    .hero h1{font-size:1.7rem}
    .section-head{padding:20px 18px 16px}
    .table-wrap{padding:0 14px 14px}
    table,thead,tbody,tr,td{display:block;width:100%}
    thead{display:none}
    table{border-spacing:0}
    tbody{display:grid;gap:14px}
    tbody tr{
        border:1px solid #e7eef7;
        border-radius:20px;
        overflow:hidden;
        background:var(--surface-soft);
    }
    tbody td{
        display:flex;
        justify-content:space-between;
        gap:14px;
        align-items:flex-start;
        white-space:normal;
        border:none;
        border-bottom:1px solid #e7eef7;
        padding:14px 16px;
    }
    tbody td:last-child{border-bottom:none}
    tbody td:first-child,
    tbody td:last-child{
        border-radius:0;
        border-right:none;
        border-left:none;
    }
    tbody td::before{
        content:attr(data-label);
        color:var(--muted);
        font-size:.8rem;
        font-weight:700;
        text-transform:uppercase;
        letter-spacing:.05em;
        min-width:110px;
    }
    .empty-row td::before{display:none}
}
@media (max-width: 560px){
    .stats{grid-template-columns:1fr}
    .section-nav{display:grid}
    .section-nav a,.summary-chip,.add{width:100%;justify-content:center}
    .section-actions{width:100%}
    .btn{width:100%}
}
</style>
</head>

<body>

<div class="layout">

<aside class="sidebar">
    <h2>YatraSathi Admin</h2>
    <p>Manage routes, watch ticket activity, and keep the whole travel system easier to monitor from one dashboard.</p>
    <nav>
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="#bus-management">Bus Management</a>
        <a href="#ticket-bookings">User Tickets</a>
        <a href="add_bus.php">Add Bus</a>
        <a href="index.php">View Site</a>
        <a href="logout.php">Logout</a>
    </nav>
</aside>

<main class="main">

<section class="hero">
    <div>
        <h1>Control routes and bookings from one live admin panel.</h1>
        <p>The dashboard now keeps bus management and ticket activity in clearly separated blocks so it feels easier to scan on desktop and cleaner to use on mobile.</p>
    </div>
    <div class="hero-panel">
        <small>Live Snapshot</small>
        <strong><?= count($buses) + count($bookings) ?></strong>
        <span>Total active records across scheduled buses and user ticket bookings.</span>
    </div>
</section>

<div class="grid stats">
    <div class="stat-card"><div class="eyebrow">Fleet</div><strong><?= count($buses) ?></strong><span>Scheduled buses</span></div>
    <div class="stat-card"><div class="eyebrow">Tickets</div><strong><?= count($bookings) ?></strong><span>Total user bookings</span></div>
    <div class="stat-card"><div class="eyebrow">Revenue Ready</div><strong><?= $paidCount ?></strong><span>Paid tickets</span></div>
    <div class="stat-card"><div class="eyebrow">Attention</div><strong><?= $cancelledCount ?></strong><span>Cancelled tickets</span></div>
</div>

<div class="section-nav">
    <a href="#bus-management">Add & Manage Buses</a>
    <a href="#ticket-bookings">User Ticket Bookings</a>
</div>

<div class="stack">
    <!-- ================= BUS MANAGEMENT ================= -->
    <section id="bus-management" class="section-card section-bus">
        <div class="section-head">
            <div class="section-title">
                <h2>Add & Manage Buses</h2>
                <p>Keep routes, prices, seat availability, and departure details organized in a dedicated fleet section that stays readable across all screen sizes.</p>
            </div>
            <div class="section-actions">
                <span class="summary-chip"><?= count($buses) ?> scheduled</span>
                <a class="add" href="add_bus.php">Add New Bus</a>
            </div>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Bus</th>
                        <th>Type</th>
                        <th>Route</th>
                        <th>Departure</th>
                        <th>Price</th>
                        <th>Seats</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($buses)): ?>
                        <tr class="empty-row">
                            <td colspan="8">No buses added yet. Use the Add New Bus button to create your first route.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($buses as $bus): ?>
                            <tr>
                                <td data-label="ID"><span class="ticket-id">#<?= (int) $bus['id'] ?></span></td>
                                <td data-label="Bus">
                                    <?= htmlspecialchars($bus['bus_name']) ?>
                                    <span class="subtext"><?= (int) $bus['total_seats'] ?> total seats</span>
                                </td>
                                <td data-label="Type"><?= htmlspecialchars($bus['bus_type'] ?: 'Standard') ?></td>
                                <td data-label="Route"><span class="route-pill"><?= htmlspecialchars($bus['source']) ?> to <?= htmlspecialchars($bus['destination']) ?></span></td>
                                <td data-label="Departure">
                                    <?= htmlspecialchars($bus['departure_date']) ?>
                                    <span class="subtext"><?= htmlspecialchars(formatDepartureTime($bus['departure_time'])) ?></span>
                                </td>
                                <td data-label="Price">Rs. <?= number_format((float) $bus['price'], 2) ?></td>
                                <td data-label="Seats">
                                    <?= (int) $bus['seats_available'] ?> available
                                    <span class="subtext">of <?= (int) $bus['total_seats'] ?></span>
                                </td>
                                <td data-label="Action">
                                    <a class="btn" href="?delete=<?= (int) $bus['id'] ?>" onclick="return confirm('Delete this bus?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- ================= BOOKINGS ================= -->
    <section id="ticket-bookings" class="section-card section-ticket">
        <div class="section-head">
            <div class="section-title">
                <h2>User Ticket Bookings</h2>
                <p>See passenger details, payment progress, and booking activity .</p>
            </div>
            <div class="section-actions">
                <span class="summary-chip"><?= $paidCount ?> paid</span>
                <span class="summary-chip"><?= $cancelledCount ?> cancelled</span>
            </div>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Ticket</th>
                        <th>Passenger Name</th>
                        <th>Bus</th>
                        <th>Route</th>
                        <th>Seats</th>
                        <th>Booking Status</th>
                        <th>Total Amount</th>
                        <th>Paid Amount</th>
                        <th>Payment</th>
                        <th>Activity Time</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($bookings)): ?>
                        <tr class="empty-row">
                            <td colspan="11">No user ticket bookings have been created yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($bookings as $booking): ?>
                            <?php
                            $statusClass = ($booking['status'] ?? '') === 'Cancelled' ? 'cancelled' : 'booked';
                            $paymentStatus = $booking['payment_row_status'] ?? $booking['payment_status'] ?? 'Unpaid';
                            $paymentClass = $paymentStatus === 'Paid' ? 'paid' : 'unpaid';
                            ?>

                            <tr>
                                <td data-label="Ticket">
                                    <span class="ticket-id"><?= htmlspecialchars($booking['ticket_number']) ?></span>
                                    <span class="subtext">#<?= (int) $booking['id'] ?></span>
                                </td>

                                <td data-label="Passenger">
                                    <?= htmlspecialchars($booking['passenger_name'] ?: $booking['user_name']) ?>
                                    <span class="subtext"><?= htmlspecialchars(getPassengerPhone($booking) ?: '-') ?></span>
                                    <span class="subtext"><?= htmlspecialchars($booking['email'] ?? '-') ?></span>
                                </td>

                                <td data-label="Bus">
                                    <?= htmlspecialchars($booking['bus_name'] ?: 'Removed Bus') ?>
                                    <span class="subtext"><?= htmlspecialchars($booking['bus_type'] ?: 'Standard') ?></span>
                                </td>

                                <td data-label="Route">
                                    <span class="route-pill"><?= htmlspecialchars($booking['source'] ?: '-') ?> to <?= htmlspecialchars($booking['destination'] ?: '-') ?></span>
                                    <span class="subtext"><?= htmlspecialchars($booking['departure_date'] ?: '-') ?> <?= htmlspecialchars(formatDepartureTime($booking['departure_time'] ?? '')) ?></span>
                                </td>

                                <td data-label="Seats">
                                    <?= htmlspecialchars($booking['seat_numbers']) ?>
                                    <span class="subtext"><?= (int) $booking['seats'] ?> seat(s)</span>
                                </td>

                                <td data-label="Status"><span class="badge <?= $statusClass ?>"><?= htmlspecialchars($booking['status']) ?></span></td>

                                <td data-label="Total Amount">
                                    Rs. <?= number_format((float) ($booking['booking_total_amount'] ?? 0), 2) ?>
                                </td>

                                <td data-label="Paid Amount">
                                    Rs. <?= number_format((float) ($booking['paid_amount'] ?? 0), 2) ?>
                                </td>

                                <td data-label="Payment">
                                    <span class="badge <?= $paymentClass ?>"><?= htmlspecialchars($paymentStatus) ?></span>
                                    <span class="subtext"><?= htmlspecialchars($booking['payment_method'] ?: 'Not selected') ?></span>
                                    <span class="subtext"><?= htmlspecialchars($booking['payment_reference'] ?: 'No reference') ?></span>
                                </td>
                                

                                <td data-label="Activity">
                                    <span class="subtext">Booked: <?= htmlspecialchars($booking['created_at'] ?? '-') ?></span>
                                    <span class="subtext">Paid: <?= htmlspecialchars($booking['paid_at'] ?? '-') ?></span>
                                    <span class="subtext">Cancelled: <?= htmlspecialchars($booking['cancelled_at'] ?? '-') ?></span>
                                </td>

                                <td data-label="Action">
                                    <form method="POST" onsubmit="return confirm('Delete this user booking?');">
                                        <input type="hidden" name="booking_id" value="<?= (int) $booking['id'] ?>">
                                        <button class="btn" type="submit" name="delete_booking" value="1">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

</main>
</div>
</body>
</html>
