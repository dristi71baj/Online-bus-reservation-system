<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    redirectTo('login.php');
}

$bookingId = (int) ($_GET['purchase_order_id'] ?? 0);
$pidx = trim($_GET['pidx'] ?? '');
$status = trim($_GET['status'] ?? '');

if ($bookingId <= 0 || $pidx === '') {
    exit('Invalid Khalti callback.');
}

$config = getPaymentConfig();
if (!isPaymentConfigured('khalti')) {
    redirectTo('payment.php?booking_id=' . $bookingId . '&error=' . urlencode('Khalti is not configured yet.'));
}

$booking = fetchBookingWithBus($conn, $bookingId, (int) $_SESSION['user_id']);
if (!$booking) {
    exit('Booking not found.');
}

if (isDepartureExpired($booking['departure_date'] ?? '', $booking['departure_time'] ?? '')) {
    redirectTo('payment.php?booking_id=' . $bookingId . '&error=' . urlencode('This bus has already departed, so Khalti payment is no longer available.'));
}

$payload = ['pidx' => $pidx];
$ch = curl_init($config['khalti']['lookup_endpoint']);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Key ' . $config['khalti']['secret_key'],
        'Content-Type: application/json',
    ],
    CURLOPT_POSTFIELDS => json_encode($payload),
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
$curlError = curl_error($ch);
curl_close($ch);
$lookup = json_decode((string) $response, true);
$expectedAmount = (int) round(calculateBookingTotal($booking) * 100);

if (
    $httpCode < 400
    && (($lookup['status'] ?? '') === 'Completed' || $status === 'Completed')
    && (int) ($lookup['total_amount'] ?? $expectedAmount) === $expectedAmount
) {
    $reference = $lookup['transaction_id'] ?? ($_GET['transaction_id'] ?? $pidx);
    markBookingPaid($conn, $bookingId, (int) $_SESSION['user_id'], 'Khalti', (string) $reference);
    redirectTo('payment_success.php?booking_id=' . $bookingId);
}

$message = 'Khalti payment verification failed.';
if ($curlError !== '') {
    $message = 'Khalti verification failed: ' . $curlError;
} elseif (!empty($lookup['status'])) {
    $message = 'Khalti payment status: ' . (string) $lookup['status'];
}

redirectTo('payment.php?booking_id=' . $bookingId . '&error=' . urlencode($message));
