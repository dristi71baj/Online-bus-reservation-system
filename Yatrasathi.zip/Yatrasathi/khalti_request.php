<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    redirectTo('login.php');
}

$bookingId = (int) ($_POST['booking_id'] ?? 0);
if ($bookingId <= 0) {
    exit('Invalid Khalti request.');
}

$config = getPaymentConfig();
$isDemoMode = isDemoPaymentMode();
if (!isPaymentConfigured('khalti')) {
    redirectTo('payment.php?booking_id=' . $bookingId . '&error=' . urlencode('Khalti is not configured yet. Please add your Khalti merchant key.'));
}

$stmt = $conn->prepare(
    "SELECT b.id, b.ticket_number, b.seats, b.total_amount, b.passenger_name, b.phone, b.payment_status,
            bs.price, bs.departure_date, bs.departure_time
     FROM bookings b
     JOIN buses bs ON bs.id = b.bus_id
     WHERE b.id = ? AND b.user_id = ? AND b.status <> 'Cancelled'
     LIMIT 1"
);
$stmt->bind_param('ii', $bookingId, $_SESSION['user_id']);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    exit('Booking not found.');
}

if (($booking['payment_status'] ?? '') === 'Paid') {
    redirectTo('payment_success.php?booking_id=' . $bookingId);
}

if (isDepartureExpired($booking['departure_date'] ?? '', $booking['departure_time'] ?? '')) {
    redirectTo('payment.php?booking_id=' . $bookingId . '&error=' . urlencode('This bus has already departed, so Khalti payment is no longer available.'));
}

if ($isDemoMode) {
    $reference = 'KHALTI-DEMO-' . strtoupper(bin2hex(random_bytes(3)));
    markBookingPaid($conn, $bookingId, (int) $_SESSION['user_id'], 'Khalti Demo', $reference);
    redirectTo('payment_success.php?booking_id=' . $bookingId . '&message=' . urlencode('Demo Khalti payment completed.'));
}

$user = fetchUser($conn, (int) $_SESSION['user_id']);
$amount = (int) round(calculateBookingTotal($booking) * 100);
$payload = [
    'return_url' => getBaseUrl('khaltiverify.php'),
    'website_url' => getBaseUrl(),
    'amount' => $amount,
    'purchase_order_id' => (string) $booking['id'],
    'purchase_order_name' => 'YatraSathi Bus Ticket ' . $booking['ticket_number'],
    'customer_info' => [
        'name' => $booking['passenger_name'] ?: ($user['name'] ?? 'YatraSathi Customer'),
        'email' => $user['email'] ?? 'customer@example.com',
        'phone' => $booking['phone'] ?: '9800000000',
    ],
];

$ch = curl_init($config['khalti']['endpoint']);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Key ' . $config['khalti']['secret_key'],
        'Content-Type: application/json',
    ],
    CURLOPT_POSTFIELDS => json_encode($payload),
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
$curlError = curl_error($ch);
curl_close($ch);

$data = json_decode((string) $response, true);
if ($httpCode >= 400 || empty($data['payment_url'])) {
    $message = 'Khalti initiation failed. Please check your Khalti merchant keys and callback domain.';
    if ($curlError !== '') {
        $message = 'Khalti initiation failed: ' . $curlError;
    } elseif (!empty($data['detail'])) {
        $message = is_array($data['detail']) ? implode(' ', array_map('strval', $data['detail'])) : (string) $data['detail'];
    }

    redirectTo('payment.php?booking_id=' . $bookingId . '&error=' . urlencode($message));
}

header('Location: ' . $data['payment_url']);
exit;
