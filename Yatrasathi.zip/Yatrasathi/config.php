<?php
// ----------------------------
// Secure session configuration
// ----------------------------

// Set session settings BEFORE starting the session
ini_set('session.use_strict_mode', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_httponly', 1);

// Enable secure cookies only if using HTTPS
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    ini_set('session.cookie_secure', 1);
}

// Set SameSite protection (important for CSRF)
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Strict'
]);

// Start session safely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ----------------------------
// Database configuration
// ----------------------------
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'yatrasathi';

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Set charset (IMPORTANT for security)
$conn->set_charset("utf8mb4");

require_once __DIR__ . '/require_once.php';
ensureBookingSchema($conn);
?>
