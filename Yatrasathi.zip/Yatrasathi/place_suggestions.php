<?php
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

$term = $_GET['term'] ?? '';
echo json_encode(getPlaces($conn, $term));
