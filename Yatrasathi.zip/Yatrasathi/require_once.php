<?php

function getBasePath(): string
{
    $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $basePath = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');

    return $basePath === '' ? '' : $basePath;
}

function getBaseUrl(string $path = ''): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $basePath = getBasePath();
    $path = ltrim($path, '/');

    return $scheme . '://' . $host . $basePath . ($path !== '' ? '/' . $path : '');
}

function redirectTo(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function ensureColumn(mysqli $conn, string $table, string $column, string $definition): void
{
    $tableEscaped = $conn->real_escape_string($table);
    $columnEscaped = $conn->real_escape_string($column);
    $dbName = $conn->real_escape_string($conn->query('SELECT DATABASE()')->fetch_row()[0] ?? '');

    $sql = "SELECT 1
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = '{$dbName}'
              AND TABLE_NAME = '{$tableEscaped}'
              AND COLUMN_NAME = '{$columnEscaped}'
            LIMIT 1";

    $exists = $conn->query($sql);

    if ($exists && $exists->num_rows === 0) {
        $conn->query("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
    }
}

function ensureBookingSchema(mysqli $conn): void
{
    $conn->query(
        "CREATE TABLE IF NOT EXISTS buses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            bus_name VARCHAR(150) NOT NULL,
            bus_type VARCHAR(60) NULL,
            source VARCHAR(120) NOT NULL,
            destination VARCHAR(120) NOT NULL,
            departure_date DATE NOT NULL,
            departure_time TIME NOT NULL,
            price DECIMAL(10,2) NOT NULL DEFAULT 0,
            seats_available INT NOT NULL DEFAULT 0,
            total_seats INT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    ensureColumn($conn, 'buses', 'bus_type', 'VARCHAR(60) NULL AFTER `bus_name`');

    $conn->query(
        "CREATE TABLE IF NOT EXISTS bookings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            bus_id INT NOT NULL,
            seats INT NOT NULL DEFAULT 0,
            total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
            seat_numbers TEXT NULL,
            passenger_name VARCHAR(150) NULL,
            phone VARCHAR(30) NULL,
            ticket_number VARCHAR(50) NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'Pending',
            payment_status VARCHAR(30) NOT NULL DEFAULT 'Unpaid',
            payment_method VARCHAR(30) NULL,
            payment_reference VARCHAR(120) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            paid_at DATETIME NULL DEFAULT NULL,
            cancelled_at DATETIME NULL DEFAULT NULL,
            INDEX idx_bookings_user (user_id),
            INDEX idx_bookings_bus (bus_id),
            INDEX idx_bookings_ticket (ticket_number)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    ensureColumn($conn, 'bookings', 'seats', 'INT NOT NULL DEFAULT 0');
    ensureColumn($conn, 'bookings', 'total_amount', 'DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `seats`');
    ensureColumn($conn, 'bookings', 'seat_numbers', 'TEXT NULL');
    ensureColumn($conn, 'bookings', 'passenger_name', 'VARCHAR(150) NULL');
    ensureColumn($conn, 'bookings', 'phone', 'VARCHAR(30) NULL');
    ensureColumn($conn, 'bookings', 'ticket_number', 'VARCHAR(50) NULL');
    ensureColumn($conn, 'bookings', 'status', "VARCHAR(30) NOT NULL DEFAULT 'Pending'");
    ensureColumn($conn, 'bookings', 'payment_status', "VARCHAR(30) NOT NULL DEFAULT 'Unpaid'");
    ensureColumn($conn, 'bookings', 'payment_method', 'VARCHAR(30) NULL');
    ensureColumn($conn, 'bookings', 'payment_reference', 'VARCHAR(120) NULL');
    ensureColumn($conn, 'bookings', 'created_at', 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP');
    ensureColumn($conn, 'bookings', 'paid_at', 'DATETIME NULL DEFAULT NULL');
    ensureColumn($conn, 'bookings', 'cancelled_at', 'DATETIME NULL DEFAULT NULL');

    $conn->query(
        "UPDATE bookings b
         JOIN buses bs ON bs.id = b.bus_id
         SET b.total_amount = ROUND(bs.price * b.seats, 2)
         WHERE b.total_amount IS NULL OR b.total_amount <= 0"
    );

    $conn->query(
        "CREATE TABLE IF NOT EXISTS payments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            booking_id INT NOT NULL,
            user_id INT NOT NULL,
            payment_method VARCHAR(30) NULL,
            payment_reference VARCHAR(120) NULL,
            total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
            paid_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
            payment_status VARCHAR(30) NOT NULL DEFAULT 'Pending',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            paid_at DATETIME NULL DEFAULT NULL,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_payments_booking (booking_id),
            KEY idx_payments_user (user_id),
            KEY idx_payments_reference (payment_reference)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );

    ensureColumn($conn, 'payments', 'booking_id', 'INT NOT NULL');
    ensureColumn($conn, 'payments', 'user_id', 'INT NOT NULL');
    ensureColumn($conn, 'payments', 'payment_method', 'VARCHAR(30) NULL');
    ensureColumn($conn, 'payments', 'payment_reference', 'VARCHAR(120) NULL');
    ensureColumn($conn, 'payments', 'total_amount', 'DECIMAL(10,2) NOT NULL DEFAULT 0');
    ensureColumn($conn, 'payments', 'paid_amount', 'DECIMAL(10,2) NOT NULL DEFAULT 0');
    ensureColumn($conn, 'payments', 'payment_status', "VARCHAR(30) NOT NULL DEFAULT 'Pending'");
    ensureColumn($conn, 'payments', 'created_at', 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP');
    ensureColumn($conn, 'payments', 'paid_at', 'DATETIME NULL DEFAULT NULL');
    ensureColumn($conn, 'payments', 'updated_at', 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');

    $conn->query(
        "INSERT INTO payments (booking_id, user_id, payment_method, payment_reference, total_amount, paid_amount, payment_status, created_at, paid_at)
         SELECT b.id, b.user_id, b.payment_method, b.payment_reference, b.total_amount,
                CASE WHEN b.payment_status = 'Paid' THEN b.total_amount ELSE 0 END AS paid_amount,
                CASE WHEN b.payment_status = 'Paid' THEN 'Paid' ELSE 'Pending' END AS payment_status,
                b.created_at,
                b.paid_at
         FROM bookings b
         LEFT JOIN payments p ON p.booking_id = b.id
         WHERE p.id IS NULL"
    );
}

function getPlaces(mysqli $conn, string $term = ''): array
{
    $term = trim($term);
    $places = [];

    if ($term !== '') {
        $like = '%' . $term . '%';
        $stmt = $conn->prepare(
            "(SELECT DISTINCT source AS place FROM buses WHERE source LIKE ?)
             UNION
             (SELECT DISTINCT destination AS place FROM buses WHERE destination LIKE ?)
             ORDER BY place ASC
             LIMIT 50"
        );
        $stmt->bind_param('ss', $like, $like);
    } else {
        $stmt = $conn->prepare(
            "(SELECT DISTINCT source AS place FROM buses)
             UNION
             (SELECT DISTINCT destination AS place FROM buses)
             ORDER BY place ASC
             LIMIT 200"
        );
    }

    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        if (!empty($row['place'])) {
            $places[] = $row['place'];
        }
    }

    $stmt->close();
    return $places;
}

function generateTicketNumber(): string
{
    return 'YT-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
}

function getPaymentConfig(): array
{
    $paymentMode = strtolower((string) (getenv('PAYMENT_MODE') ?: 'demo'));
    $esewaProductCode = getenv('ESEWA_PRODUCT_CODE') ?: 'EPAYTEST';
    $esewaSecretKey = getenv('ESEWA_SECRET_KEY') ?: '8gBm/:&EnhH.1/q';
    $khaltiSecretKey = getenv('KHALTI_SECRET_KEY') ?: '';
    $isDemo = $paymentMode === 'demo';
    $useLiveGateways = $paymentMode === 'live';

    return [
        'esewa' => [
            'enabled' => true,
            'product_code' => $esewaProductCode,
            'secret_key' => $esewaSecretKey,
            'mode' => $useLiveGateways ? 'Live' : 'Test',
            'endpoint' => $useLiveGateways
                ? 'https://epay.esewa.com.np/api/epay/main/v2/form'
                : 'https://rc-epay.esewa.com.np/api/epay/main/v2/form',
        ],
        'khalti' => [
            'enabled' => $isDemo || $khaltiSecretKey !== '',
            'secret_key' => $khaltiSecretKey,
            'mode' => $isDemo ? 'Demo' : ($useLiveGateways ? 'Live' : 'Test'),
            'endpoint' => $useLiveGateways
                ? 'https://khalti.com/api/v2/epayment/initiate/'
                : 'https://dev.khalti.com/api/v2/epayment/initiate/',
            'lookup_endpoint' => $useLiveGateways
                ? 'https://khalti.com/api/v2/epayment/lookup/'
                : 'https://dev.khalti.com/api/v2/epayment/lookup/',
        ],
        'demo' => [
            'enabled' => $isDemo,
            'mode' => $isDemo ? 'Demo' : 'Configured',
        ],
    ];
}

function isPaymentConfigured(string $method): bool
{
    $config = getPaymentConfig();
    if ($method === 'khalti' && !empty($config['demo']['enabled'])) {
        return true;
    }

    return !empty($config[$method]['enabled']) && ($method !== 'khalti' || !empty($config[$method]['secret_key']));
}

function isDemoPaymentMode(): bool
{
    $config = getPaymentConfig();
    return !empty($config['demo']['enabled']);
}

function createEsewaSignature(string $message, string $secretKey): string
{
    return base64_encode(hash_hmac('sha256', $message, $secretKey, true));
}

function fetchUser(mysqli $conn, int $userId): ?array
{
    $stmt = $conn->prepare("SELECT id, name, email FROM users WHERE id = ?");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();

    return $user;
}

function formatBookingStatus(array $booking): string
{
    if (($booking['status'] ?? '') === 'Cancelled') {
        return 'Cancelled';
    }

    if (($booking['payment_status'] ?? '') === 'Paid') {
        return 'Paid';
    }

    return $booking['status'] ?? 'Pending';
}

function fetchBookingWithBus(mysqli $conn, int $bookingId, int $userId): ?array
{
    $stmt = $conn->prepare(
        "SELECT b.*, b.phone AS passenger_phone, bs.bus_name, bs.source, bs.destination, bs.departure_date, bs.departure_time, bs.price,
                p.paid_amount, p.payment_status AS payment_row_status, p.paid_at AS payment_paid_at
         FROM bookings b
         JOIN buses bs ON bs.id = b.bus_id
         LEFT JOIN payments p ON p.booking_id = b.id
         WHERE b.id = ? AND b.user_id = ?
         LIMIT 1"
    );
    $stmt->bind_param('ii', $bookingId, $userId);
    $stmt->execute();
    $booking = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();

    return $booking;
}

function calculateBookingTotal(array $booking): float
{
    $storedTotal = isset($booking['total_amount']) ? (float) $booking['total_amount'] : 0.0;
    if ($storedTotal > 0) {
        return $storedTotal;
    }

    return round((float) ($booking['price'] ?? 0) * (int) ($booking['seats'] ?? 0), 2);
}

function upsertBookingPaymentRecord(
    mysqli $conn,
    int $bookingId,
    int $userId,
    float $totalAmount,
    string $status,
    float $paidAmount = 0.0,
    ?string $method = null,
    ?string $reference = null,
    bool $markPaidAt = false
): void {
    $paidAtSql = $markPaidAt ? 'NOW()' : 'NULL';
    $stmt = $conn->prepare(
        "INSERT INTO payments (booking_id, user_id, payment_method, payment_reference, total_amount, paid_amount, payment_status, created_at, paid_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), {$paidAtSql})
         ON DUPLICATE KEY UPDATE
            user_id = VALUES(user_id),
            payment_method = VALUES(payment_method),
            payment_reference = VALUES(payment_reference),
            total_amount = VALUES(total_amount),
            paid_amount = VALUES(paid_amount),
            payment_status = VALUES(payment_status),
            paid_at = " . ($markPaidAt ? 'NOW()' : 'IF(VALUES(payment_status) = \'Paid\', paid_at, NULL)')
    );
    $stmt->bind_param('iissdds', $bookingId, $userId, $method, $reference, $totalAmount, $paidAmount, $status);
    $stmt->execute();
    $stmt->close();
}

function markBookingPaid(mysqli $conn, int $bookingId, int $userId, string $method, string $reference): bool
{
    $bookingStmt = $conn->prepare(
        "SELECT b.id, b.user_id, b.status, b.seats, b.total_amount, bs.price
         FROM bookings b
         JOIN buses bs ON bs.id = b.bus_id
         WHERE b.id = ? AND b.user_id = ?
         LIMIT 1"
    );
    $bookingStmt->bind_param('ii', $bookingId, $userId);
    $bookingStmt->execute();
    $booking = $bookingStmt->get_result()->fetch_assoc();
    $bookingStmt->close();

    if (!$booking || ($booking['status'] ?? '') === 'Cancelled') {
        return false;
    }

    $totalAmount = calculateBookingTotal($booking);

    $conn->begin_transaction();

    try {
        $stmt = $conn->prepare(
            "UPDATE bookings
             SET total_amount = ?, payment_status = 'Paid', payment_method = ?, payment_reference = ?, paid_at = NOW()
             WHERE id = ? AND user_id = ? AND status <> 'Cancelled'"
        );
        $stmt->bind_param('dssii', $totalAmount, $method, $reference, $bookingId, $userId);
        $stmt->execute();
        $updated = $stmt->affected_rows >= 1;
        $stmt->close();

        upsertBookingPaymentRecord($conn, $bookingId, $userId, $totalAmount, 'Paid', $totalAmount, $method, $reference, true);

        $conn->commit();

        return true;
    } catch (Throwable $e) {
        $conn->rollback();
        return false;
    }
}

function getPassengerPhone(array $booking): string
{
    return trim((string) ($booking['passenger_phone'] ?? $booking['phone'] ?? ''));
}

function formatDepartureTime(?string $time): string
{
    $time = trim((string) $time);
    if ($time === '') {
        return '-';
    }

    $timestamp = strtotime($time);
    if ($timestamp === false) {
        return $time;
    }

    return date('h:i A', $timestamp);
}

function getAppTimezone(): DateTimeZone
{
    return new DateTimeZone('Asia/Kathmandu');
}

function isDepartureExpired(?string $departureDate, ?string $departureTime): bool
{
    $departureDate = trim((string) $departureDate);
    $departureTime = trim((string) $departureTime);

    if ($departureDate === '' || $departureTime === '') {
        return false;
    }

    try {
        $timezone = getAppTimezone();
        $departure = new DateTime($departureDate . ' ' . $departureTime, $timezone);
        $now = new DateTime('now', $timezone);

        return $departure < $now;
    } catch (Throwable $e) {
        return false;
    }
}

function getSmoothBackUrl(string $fallback = 'index.php'): string
{
    $fallbackUrl = $fallback;
    $referer = trim((string) ($_SERVER['HTTP_REFERER'] ?? ''));

    if ($referer === '') {
        return $fallbackUrl;
    }

    $refererParts = parse_url($referer);
    $currentHost = $_SERVER['HTTP_HOST'] ?? '';

    if (!empty($refererParts['host']) && strcasecmp((string) $refererParts['host'], (string) $currentHost) !== 0) {
        return $fallbackUrl;
    }

    $path = (string) ($refererParts['path'] ?? '');
    if ($path === '' || basename($path) === basename($_SERVER['SCRIPT_NAME'] ?? '')) {
        return $fallbackUrl;
    }

    $url = $path;
    if (!empty($refererParts['query'])) {
        $url .= '?' . $refererParts['query'];
    }

    return ltrim($url, '/');
}
