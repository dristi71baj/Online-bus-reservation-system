<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    redirectTo('login.php');
}

$bookingId = (int) ($_GET['booking_id'] ?? 0);
$gateway = strtolower(trim((string) ($_GET['gateway'] ?? '')));

if ($bookingId <= 0 || !in_array($gateway, ['esewa', 'khalti'], true)) {
    exit('Invalid demo gateway request.');
}

if (!isDemoPaymentMode()) {
    redirectTo('payment.php?booking_id=' . $bookingId);
}

$booking = fetchBookingWithBus($conn, $bookingId, (int) $_SESSION['user_id']);
if (!$booking) {
    exit('Booking not found.');
}

$isExpired = isDepartureExpired($booking['departure_date'] ?? '', $booking['departure_time'] ?? '');
if (($booking['status'] ?? '') === 'Cancelled' || ($booking['payment_status'] ?? '') === 'Paid' || $isExpired) {
    redirectTo('payment.php?booking_id=' . $bookingId);
}


$passengerPhone = getPassengerPhone($booking);
$totalAmount = calculateBookingTotal($booking);
$isEsewa = $gateway === 'esewa';
$brandName = $isEsewa ? 'eSewa' : 'Khalti';
$pageTitle = $isEsewa ? 'eSewa  Checkout' : 'Khalti  Checkout';
$brandClass = $isEsewa ? 'theme-esewa' : 'theme-khalti';
$brandWord = $isEsewa ? 'eSewa' : 'khalti';
$brandTagline = $isEsewa
    ? 'Digital wallet payment for your YatraSathi ticket.'
    : 'Digital payment for your YatraSathi ticket.';
$actionUrl = $isEsewa
    ? 'esewapayment.php'
    : 'khalti_request.php';
$actionMethod = $isEsewa ? 'GET' : 'POST';
$cancelUrl = 'payment.php?booking_id=' . $bookingId . '&error=' . urlencode($brandName . ' demo payment was cancelled.');
$fakeReference = strtoupper(($isEsewa ? 'ESW' : 'KLT') . '-' . date('ymd') . '-' . substr(bin2hex(random_bytes(3)), 0, 6));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<style>
:root{
    --text:#17324c;
    --muted:#617489;
    --surface:#ffffff;
    --border:rgba(18,55,95,.12);
    --shadow:0 24px 48px rgba(16,43,71,.14);
}
*{box-sizing:border-box}
body{
    margin:0;
    font-family:Arial,sans-serif;
    color:var(--text);
}
body.theme-esewa{
    background:linear-gradient(180deg,#eef9eb 0%,#f8fff5 100%);
    --brand:#60bb46;
    --brand-strong:#3e9728;
    --brand-soft:#eef9eb;
}
body.theme-khalti{
    background:linear-gradient(180deg,#f4edff 0%,#fcf8ff 100%);
    --brand:#5c2d91;
    --brand-strong:#44186f;
    --brand-soft:#f3ebff;
}
.page{max-width:1180px;margin:0 auto;padding:28px 18px 40px}
.topbar{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:18px}
.topbar a{text-decoration:none;color:var(--brand-strong);font-weight:700}
.layout{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(320px,.9fr);gap:22px}
.hero{
    background:linear-gradient(145deg,var(--brand-strong),var(--brand));
    color:#fff;
    border-radius:28px;
    padding:26px;
    box-shadow:var(--shadow);
    position:relative;
    overflow:hidden;
}
.hero:after{
    content:"";
    position:absolute;
    width:220px;
    height:220px;
    right:-60px;
    top:-40px;
    background:rgba(255,255,255,.10);
    border-radius:50%;
}
.brand-badge{
    display:inline-flex;
    align-items:center;
    gap:10px;
    padding:10px 14px;
    border-radius:999px;
    background:rgba(255,255,255,.14);
    border:1px solid rgba(255,255,255,.16);
    margin-bottom:16px;
}
.logo-mark{
    width:36px;
    height:36px;
    border-radius:12px;
    background:#fff;
    color:var(--brand-strong);
    display:grid;
    place-items:center;
    font-weight:900;
    font-size:1rem;
}
.wordmark{
    font-size:1.45rem;
    font-weight:900;
    letter-spacing:.01em;
    text-transform:none;
}
.hero h1{margin:0;font-size:2rem;line-height:1.1}
.hero p{margin:12px 0 0;color:rgba(255,255,255,.84);max-width:620px;line-height:1.6}
.hero-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:20px}
.hero-card{
    background:rgba(255,255,255,.12);
    border:1px solid rgba(255,255,255,.14);
    border-radius:18px;
    padding:14px;
}
.hero-card span{display:block;font-size:.8rem;color:rgba(255,255,255,.72);text-transform:uppercase;letter-spacing:.06em}
.hero-card strong{display:block;margin-top:8px;font-size:1.06rem}
.panel{
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:26px;
    box-shadow:var(--shadow);
    overflow:hidden;
}
.panel-head{
    padding:22px 22px 18px;
    background:linear-gradient(180deg,var(--brand-soft),#fff);
    border-bottom:1px solid var(--border);
}
.panel-head h2{margin:0 0 8px}
.panel-head p{margin:0;color:var(--muted);line-height:1.5}
.panel-body{padding:22px}
.amount-box{
    border-radius:22px;
    padding:20px;
    background:linear-gradient(160deg,var(--brand-strong),var(--brand));
    color:#fff;
    margin-bottom:16px;
}
.amount-box small{display:block;color:rgba(255,255,255,.76);text-transform:uppercase;letter-spacing:.07em}
.amount-box strong{display:block;font-size:2rem;margin-top:8px}
.detail-grid{display:grid;gap:12px;margin-bottom:16px}
.detail{
    display:flex;
    justify-content:space-between;
    gap:12px;
    align-items:flex-start;
    padding:14px 16px;
    border-radius:16px;
    background:#f9fbff;
    border:1px solid var(--border);
}
.detail span{color:var(--muted);font-size:.9rem}
.detail strong{text-align:right}
.note{
    padding:14px 16px;
    border-radius:16px;
    background:var(--brand-soft);
    color:var(--brand-strong);
    border:1px solid rgba(0,0,0,.06);
    line-height:1.5;
    margin-bottom:16px;
}
.wallet-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-bottom:18px}
.wallet-box{
    padding:16px;
    border-radius:18px;
    background:#fff;
    border:1px solid var(--border);
}
.wallet-box h3{margin:0 0 8px;font-size:1rem}
.wallet-box p{margin:0;color:var(--muted);line-height:1.5}
.actions{display:grid;grid-template-columns:1fr 1fr;gap:12px}
button,.ghost{
    display:inline-flex;
    justify-content:center;
    align-items:center;
    width:100%;
    min-height:52px;
    border:none;
    border-radius:16px;
    font-weight:800;
    font-size:1rem;
    text-decoration:none;
    cursor:pointer;
}
.pay-btn{
    background:linear-gradient(135deg,var(--brand-strong),var(--brand));
    color:#fff;
    box-shadow:0 14px 28px rgba(0,0,0,.14);
}
.ghost{
    background:#fff;
    color:var(--brand-strong);
    border:1px solid var(--border);
}
.footer-meta{
    margin-top:16px;
    color:var(--muted);
    font-size:.9rem;
    text-align:center;
}
@media (max-width: 920px){
    .layout{grid-template-columns:1fr}
}
@media (max-width: 620px){
    .page{padding:20px 14px 28px}
    .hero{padding:22px}
    .hero h1{font-size:1.7rem}
    .hero-grid,.wallet-grid,.actions{grid-template-columns:1fr}
    .detail{flex-direction:column}
    .detail strong{text-align:left}
}
</style>
</head>
<body class="<?= htmlspecialchars($brandClass) ?>">
<div class="page">
    <div class="topbar">
        <a href="payment.php?booking_id=<?= (int) $bookingId ?>">Back to Payment</a>
        <a href="my_bookings.php">My Bookings</a>
    </div>

    <div class="layout">
        <section class="hero">
            <div class="brand-badge">
                <div class="logo-mark"><?= $isEsewa ? 'eS' : 'K' ?></div>
                <div class="wordmark"><?= htmlspecialchars($brandWord) ?></div>
            </div>
            <h1><?= htmlspecialchars($pageTitle) ?></h1>
            <p><?= htmlspecialchars($brandTagline) ?> This screen is local to YatraSathi and is only meant to simulate a familiar wallet checkout experience.</p>
            <div class="hero-grid">
                <div class="hero-card">
                    <span>Merchant</span>
                    <strong>YatraSathi</strong>
                </div>
                <div class="hero-card">
                    <span>Reference</span>
                    <strong><?= htmlspecialchars($fakeReference) ?></strong>
                </div>
                <div class="hero-card">
                    <span>Status</span>
                    <strong>Awaiting Payment</strong>
                </div>
            </div>
        </section>

        <section class="panel">
            <div class="panel-head">
                <h2>Confirm  Payment</h2>
                <p>Review the ticket summary below and choose whether to complete or cancel this  <?= htmlspecialchars($brandName) ?> payment.</p>
            </div>
            <div class="panel-body">
                <div class="amount-box">
                    <small>Total Amount</small>
                    <strong>Rs. <?= number_format($totalAmount, 2) ?></strong>
                </div>

                <div class="detail-grid">
                    <div class="detail"><span>Ticket Number</span><strong><?= htmlspecialchars($booking['ticket_number']) ?></strong></div>
                    <div class="detail"><span>Passenger</span><strong><?= htmlspecialchars($booking['passenger_name']) ?></strong></div>
                    <div class="detail"><span>Phone</span><strong><?= htmlspecialchars($passengerPhone ?: '-') ?></strong></div>
                    <div class="detail"><span>Seats</span><strong><?= htmlspecialchars($booking['seat_numbers']) ?></strong></div>
                    <div class="detail"><span>Route</span><strong><?= htmlspecialchars($booking['source']) ?> to <?= htmlspecialchars($booking['destination']) ?></strong></div>
                </div>

                <div class="wallet-grid">
                    <div class="wallet-box">
                        <h3><?= htmlspecialchars($brandName) ?> Wallet</h3>
                        <p>Balance looks ready for this  transaction.</p>
                    </div>
                    <div class="wallet-box">
                        <h3>Security Check</h3>
                        <p>Reference `<?= htmlspecialchars($fakeReference) ?>` will be converted into a local payment confirmation after you continue.</p>
                    </div>
                </div>

                <div class="actions">
                    <?php if ($isEsewa): ?>
                        <form action="<?= htmlspecialchars($actionUrl) ?>" method="<?= htmlspecialchars($actionMethod) ?>">
                            <input type="hidden" name="booking_id" value="<?= (int) $bookingId ?>">
                            <input type="hidden" name="status" value="success">
                            <input type="hidden" name="demo" value="1">
                            <button class="pay-btn" type="submit">Confirm <?= htmlspecialchars($brandName) ?> Payment</button>
                        </form>
                    <?php else: ?>
                        <form action="<?= htmlspecialchars($actionUrl) ?>" method="<?= htmlspecialchars($actionMethod) ?>">
                            <input type="hidden" name="booking_id" value="<?= (int) $bookingId ?>">
                            <input type="hidden" name="demo" value="1">
                            <button class="pay-btn" type="submit">Confirm <?= htmlspecialchars($brandName) ?> Payment</button>
                        </form>
                    <?php endif; ?>

                    <a class="ghost" href="<?= htmlspecialchars($cancelUrl) ?>">Cancel Payment</a>
                </div>
            </div>
        </section>
    </div>
</div>
</body>
</html>
