<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    redirectTo('login.php');
}

$stmt = $conn->prepare(
    "SELECT b.*, b.phone AS passenger_phone, bs.bus_name, bs.source, bs.destination, bs.departure_date, bs.departure_time, bs.price
     FROM bookings b
     JOIN buses bs ON bs.id = b.bus_id
     WHERE b.user_id = ?
     ORDER BY b.created_at DESC, b.id DESC"
);
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$bookings = [];
while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}
$stmt->close();

$user = fetchUser($conn, (int) $_SESSION['user_id']);
$backUrl = getSmoothBackUrl('index.php');
$bookingStats = [
    'total' => count($bookings),
    'paid' => 0,
    'pending' => 0,
    'cancelled' => 0,
    'spent' => 0.0,
];

foreach ($bookings as $booking) {
    $total = calculateBookingTotal($booking);
    if (($booking['status'] ?? '') === 'Cancelled') {
        $bookingStats['cancelled']++;
        continue;
    }
    if (($booking['payment_status'] ?? '') === 'Paid') {
        $bookingStats['paid']++;
        $bookingStats['spent'] += $total;
    } else {
        $bookingStats['pending']++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Bookings | YatraSathi</title>
<style>
body{margin:0;font-family:Arial,sans-serif;background:#eef4ff;color:#17324c}
.page{max-width:1180px;margin:0 auto;padding:28px 18px 40px}
.topbar{display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:18px}
.topbar a{color:#1f6fd6;text-decoration:none;font-weight:700}
.hero{background:linear-gradient(135deg,#0f4c81,#1f6fd6);color:#fff;border-radius:24px;padding:24px;box-shadow:0 20px 45px rgba(17,55,95,.18);margin-bottom:18px}
.hero p{color:#dcecff;margin-top:8px}
.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:18px}
.stat{background:#fff;border-radius:18px;padding:18px;box-shadow:0 12px 30px rgba(17,55,95,.08)}
.stat .count{font-size:1.7rem;font-weight:700;color:#0f4c81}
.stat .label{margin-top:6px}
.toolbar{display:flex;gap:12px;flex-wrap:wrap;align-items:center;justify-content:space-between;background:#fff;border-radius:18px;padding:16px 18px;box-shadow:0 12px 30px rgba(17,55,95,.08);margin-bottom:18px}
.filters{display:flex;gap:10px;flex-wrap:wrap}
.filters button,.search-box{border:1px solid #c7d7ea;border-radius:999px;background:#fff;color:#17324c}
.filters button{padding:10px 14px;font-weight:700;cursor:pointer}
.filters button.active{background:#1f6fd6;color:#fff;border-color:#1f6fd6}
.search-box{padding:10px 14px;min-width:260px}
.list{display:grid;gap:16px}
.card{background:#fff;border-radius:20px;padding:20px;box-shadow:0 12px 30px rgba(17,55,95,.08)}
.head{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:12px}
.ticket{font-size:1.15rem;font-weight:700}
.badge{padding:8px 12px;border-radius:999px;font-size:.86rem;font-weight:700}
.badge-paid{background:#e9f9ee;color:#116329}
.badge-unpaid{background:#fff7e6;color:#8a5a00}
.badge-cancelled{background:#fff1f1;color:#b42318}
.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}
.label{font-size:.82rem;color:#6b7e92;text-transform:uppercase;letter-spacing:.04em}
.value{font-weight:700}
.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}
.btn,button{display:inline-flex;justify-content:center;align-items:center;padding:12px 14px;border:none;border-radius:12px;font-weight:700;text-decoration:none;cursor:pointer}
.pay{background:#1f6fd6;color:#fff}
.print{background:#edf4ff;color:#1f6fd6}
.cancel{background:#fff1f1;color:#b42318}
.empty{background:#fff;border-radius:20px;padding:26px;text-align:center;box-shadow:0 12px 30px rgba(17,55,95,.08)}
.hidden{display:none}
@media (max-width: 900px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width: 560px){.grid{grid-template-columns:1fr}.page{padding:22px 14px 32px}.stats{grid-template-columns:1fr}.toolbar{align-items:stretch}.search-box{width:100%;min-width:0}}
</style>
</head>
<body>
<div class="page">
    <div class="hero">
        <div>
            <h1><?= htmlspecialchars($user['name'] ?? 'My Bus Bookings') ?></h1>
            <p>Your travel dashboard updates live with paid, pending, and cancelled tickets after login.</p>
        </div>
    </div>

    <div class="topbar">
        <div>
            <h2>My Bus Bookings</h2>
            <p>View your own tickets, pay pending bookings, cancel, or print.</p>
        </div>
<a href="index.php">Back to Home</a>    </div>

    <div class="stats">
        <div class="stat"><div class="count"><?= number_format($bookingStats['total']) ?></div><div class="label">Total bookings</div></div>
        <div class="stat"><div class="count"><?= number_format($bookingStats['paid']) ?></div><div class="label">Paid tickets</div></div>
        <div class="stat"><div class="count"><?= number_format($bookingStats['pending']) ?></div><div class="label">Pending payments</div></div>
        <div class="stat"><div class="count">Rs. <?= number_format($bookingStats['spent'], 2) ?></div><div class="label">Completed spend</div></div>
    </div>
<?php if (isset($_SESSION['flash_msg'])): ?>
<script>
    alert("<?= $_SESSION['flash_msg']; ?>");
</script>
<?php unset($_SESSION['flash_msg']); ?>
<?php endif; ?>
    <?php if (empty($bookings)): ?>
        <div class="empty">
            <h2>No bookings yet</h2>
            <p>Your bus tickets will appear here after you confirm a booking.</p>
        </div>
    <?php else: ?>
        <div class="toolbar">
            <div class="filters">
                <button type="button" class="active" data-filter="all">All</button>
                <button type="button" data-filter="paid">Paid</button>
                <button type="button" data-filter="pending">Pending</button>
                <button type="button" data-filter="cancelled">Cancelled</button>
            </div>
            <input type="search" id="bookingSearch" class="search-box" placeholder="Search by ticket, route, passenger, or bus">
        </div>

        <div class="list">
            <?php foreach ($bookings as $booking): ?>
                <?php
                    $status = formatBookingStatus($booking);
                    $badgeClass = ($status === 'Cancelled') ? 'badge-cancelled' : (($booking['payment_status'] ?? '') === 'Paid' ? 'badge-paid' : 'badge-unpaid');
                    $total = calculateBookingTotal($booking);
                    $filterStatus = ($status === 'Cancelled') ? 'cancelled' : ((($booking['payment_status'] ?? '') === 'Paid') ? 'paid' : 'pending');
                    $bookingPhone = getPassengerPhone($booking);
                    $passengerCount = max(1, (int) ($booking['seats'] ?? 0));
                    $searchText = strtolower(implode(' ', [
                        $booking['ticket_number'],
                        $booking['bus_name'],
                        $booking['source'],
                        $booking['destination'],
                        $booking['passenger_name'],
                        $bookingPhone,
                    ]));
                ?>
                <div class="card" data-status="<?= htmlspecialchars($filterStatus) ?>" data-search="<?= htmlspecialchars($searchText) ?>" data-ticket='<?= htmlspecialchars(json_encode([
                    'ticket_number' => $booking['ticket_number'],
                    'bus_name' => $booking['bus_name'],
                    'route' => $booking['source'] . ' to ' . $booking['destination'],
                    'departure' => $booking['departure_date'] . ' ' . $booking['departure_time'],
                    'passenger_name' => $booking['passenger_name'],
                    'passenger_phone' => $bookingPhone,
                    'passenger_count' => $passengerCount,
                    'seat_numbers' => $booking['seat_numbers'],
                    'payment_status' => $booking['payment_status'],
                    'status' => $status,
                ]), ENT_QUOTES) ?>'>
                    <div class="head">
                        <div>
                            <div class="ticket">Ticket <?= htmlspecialchars($booking['ticket_number']) ?></div>
                            <div><?= htmlspecialchars($booking['bus_name']) ?></div>
                        </div>
                        <span class="badge <?= $badgeClass ?>"><?= htmlspecialchars($status) ?><?php if (($booking['payment_status'] ?? '') === 'Paid' && $status !== 'Cancelled'): ?> / Paid<?php endif; ?></span>
                    </div>

                    <div class="grid">
                        <div><div class="label">Route</div><div class="value"><?= htmlspecialchars($booking['source']) ?> to <?= htmlspecialchars($booking['destination']) ?></div></div>
                        <div><div class="label">Departure</div><div class="value"><?= htmlspecialchars($booking['departure_date']) ?><br><?= htmlspecialchars(formatDepartureTime($booking['departure_time'])) ?></div></div>
                        <div><div class="label">Passenger</div><div class="value"><?= htmlspecialchars($booking['passenger_name']) ?><br>Number: <?= htmlspecialchars($bookingPhone ?: '-') ?></div></div>
                        <div><div class="label">Seats / Total</div><div class="value"><?= htmlspecialchars($booking['seat_numbers']) ?><br>Rs. <?= number_format($total, 2) ?></div></div>
                    </div>

                    <div class="actions">
                      <?php
$isExpired = isDepartureExpired($booking['departure_date'] ?? '', $booking['departure_time'] ?? '');
?>

<?php if (($booking['status'] ?? '') !== 'Cancelled' && ($booking['payment_status'] ?? '') !== 'Paid'): ?>

    <?php if ($isExpired): ?>
        <button class="btn pay" style="background:#aaa;cursor:not-allowed;" disabled>
            Payment is Expired as the bus is already departed
        </button>
    <?php else: ?>
        <a class="btn pay" href="payment.php?booking_id=<?= (int) $booking['id'] ?>">
            Pay Now
        </a>
    <?php endif; ?>

<?php endif; ?>

                        <?php if (($booking['status'] ?? '') !== 'Cancelled'): ?>
                            <form action="cancel_ticket.php" method="POST" onsubmit="return confirm('Cancel this booking?');">
                                <input type="hidden" name="booking_id" value="<?= (int) $booking['id'] ?>">
                                <button class="cancel" type="submit">Cancel Booking</button>
                            </form>
                        <?php endif; ?>

                        <button class="print" type="button" onclick="printTicket(this)">Print Ticket</button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script>
const cards = Array.from(document.querySelectorAll('.card[data-status]'));
const filterButtons = Array.from(document.querySelectorAll('.filters button'));
const searchInput = document.getElementById('bookingSearch');

function applyBookingFilters() {
    if (!cards.length) {
        return;
    }

    const activeButton = document.querySelector('.filters button.active');
    const filter = activeButton ? activeButton.dataset.filter : 'all';
    const keyword = (searchInput ? searchInput.value : '').trim().toLowerCase();

    cards.forEach((card) => {
        const matchesFilter = filter === 'all' || card.dataset.status === filter;
        const matchesSearch = keyword === '' || (card.dataset.search || '').includes(keyword);
        card.classList.toggle('hidden', !(matchesFilter && matchesSearch));
    });
}

filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
        filterButtons.forEach((item) => item.classList.remove('active'));
        button.classList.add('active');
        applyBookingFilters();
    });
});

if (searchInput) {
    searchInput.addEventListener('input', applyBookingFilters);
}

function printTicket(button) {
    const card = button.closest('.card');
    const data = JSON.parse(card.dataset.ticket);
    const html = `
        <html>
        <head>
            <title>Print Ticket</title>
            <style>
                body{font-family:Arial,sans-serif;padding:24px;color:#17324c}
                .ticket{border:2px dashed #1f6fd6;border-radius:18px;padding:22px;max-width:520px;margin:0 auto}
                h1{margin-top:0}
                p{margin:10px 0}
            </style>
        </head>
        <body>
            <div class="ticket">
                <h1>YatraSathi Bus Ticket</h1>
                <p><strong>Ticket Number:</strong> ${data.ticket_number}</p>
                <p><strong>Bus:</strong> ${data.bus_name}</p>
                <p><strong>Route:</strong> ${data.route}</p>
                <p><strong>Departure:</strong> ${data.departure}</p>
                <p><strong>Passenger:</strong> ${data.passenger_name}</p>
                <p><strong>Passenger Number:</strong> ${data.passenger_phone || '-'}</p>
                <p><strong>Passenger Count:</strong> ${data.passenger_count}</p>
                <p><strong>Seats:</strong> ${data.seat_numbers}</p>
                <p><strong>Status:</strong> ${data.status}</p>
                <p><strong>Payment:</strong> ${data.payment_status}</p>
            </div>
        </body>
        </html>`;

    const win = window.open('', '_blank', 'width=720,height=720');
    win.document.write(html);
    win.document.close();
    win.focus();
    win.print();
}

applyBookingFilters();

document.querySelectorAll('.js-back-link').forEach((link) => {
    link.addEventListener('click', (event) => {
        if (window.history.length > 1 && document.referrer) {
            event.preventDefault();
            window.history.back();
        }
    });
});
</script>
</body>
</html>
