<?php
require_once 'config.php';
redirectTo('my_bookings.php');
