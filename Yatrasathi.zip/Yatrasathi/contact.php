<?php
require_once 'config.php';
$userLoggedIn = isset($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Us | YatraSathi</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Roboto',sans-serif;background:#eef4ff;color:#15304c;line-height:1.6}a{text-decoration:none}.navbar{display:flex;justify-content:space-between;align-items:center;gap:18px;padding:18px 24px;background:#0f4c81;color:#fff;flex-wrap:wrap}.brand{font-size:1.4rem;font-weight:700}.nav-links{display:flex;flex-wrap:wrap;gap:14px}.nav-links a{color:#fff;font-weight:500}.hero{padding:56px 20px;background:linear-gradient(135deg,rgba(15,76,129,.92),rgba(31,111,214,.82)),url('https://images.unsplash.com/photo-1494412574643-ff11b0a5c1c3') center/cover no-repeat;color:#fff}.hero-inner{max-width:1120px;margin:0 auto}.hero h1{font-size:clamp(2rem,5vw,3.4rem);margin-bottom:12px}.hero p{max-width:680px;color:#dcecff}.section{padding:54px 20px}.section-inner{max-width:1120px;margin:0 auto}.grid{display:grid;gap:18px}.grid-2{grid-template-columns:1fr 1fr}.grid-3{grid-template-columns:repeat(auto-fit,minmax(250px,1fr))}.card{background:#fff;padding:24px;border-radius:20px;box-shadow:0 10px 28px rgba(21,57,93,.08)}.card h3,.card h4{color:#0f4c81;margin-bottom:10px}.socials{display:flex;gap:12px;flex-wrap:wrap;margin-top:18px}.socials a{display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;border-radius:50%;background:#edf4ff;color:#1f6fd6;font-size:1.3rem}.highlight{background:linear-gradient(180deg,#ffffff,#f3f8ff)}footer{padding:20px;background:#0f4c81;color:#fff;text-align:center}@media (max-width: 860px){.grid-2{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="navbar"><div class="brand">YatraSathi</div><div class="nav-links"><a href="index.php">Home</a><a href="aboutus.php">About</a><a href="contact.php">Contact</a><?php if ($userLoggedIn): ?><a href="my_bookings.php">My Bookings</a><a href="logout.php">Logout</a><?php else: ?><a href="login.php">Login</a><a href="register.php">Register</a><?php endif; ?></div></div>
<section class="hero"><div class="hero-inner"><h1>Reach the YatraSathi team anytime your journey needs help.</h1><p>Use this page for support, payment questions, route feedback, booking issues, or business partnership requests.</p></div></section>
<section class="section"><div class="section-inner grid grid-2"><div class="card highlight"><h3>Contact details</h3><p><strong>Phone:</strong> +977-9800000000</p><p><strong>Email:</strong> support@yatrasathi.com</p><p><strong>Office hours:</strong> 6:00 AM to 10:00 PM every day</p><p><strong>Location:</strong> Kathmandu, Nepal</p><div class="socials"><a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f"></i></a><a href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram"></i></a><a href="https://wa.me/9779800000000" target="_blank"><i class="fab fa-whatsapp"></i></a></div></div><div class="card"><h3>How we can help</h3><p>Passengers can contact us for route availability, payment follow-up, cancellation support, ticket recovery, and booking confirmation assistance.</p><p>Bus operators and admins can use YatraSathi to organize schedules, view booking activity, and track payment and cancellation status from the admin dashboard.</p><p>For urgent travel day issues, phone or WhatsApp support will be the fastest option.</p></div></div></section>
<section class="section" style="padding-top:0"><div class="section-inner"><div class="grid grid-3"><div class="card"><h4>Payment Help</h4><p>Need help after paying with eSewa or Khalti? Share your ticket number and payment reference.</p></div><div class="card"><h4>Booking Help</h4><p>If you booked the wrong seat or route, contact support before departure for the best chance of adjustment.</p></div><div class="card"><h4>Travel Feedback</h4><p>Route reviews and operator feedback help improve what travelers see on the platform.</p></div></div></div></section>
<footer>&copy; <?= date('Y') ?> YatraSathi. All rights reserved.</footer>
</body>
</html>
