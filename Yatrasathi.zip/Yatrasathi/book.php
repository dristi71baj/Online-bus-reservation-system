<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    redirectTo('login.php');
}

$busId = (int) ($_GET['bus_id'] ?? $_POST['bus_id'] ?? 0);
if ($busId <= 0) {
    exit('Invalid bus selection.');
}

$userId = (int) $_SESSION['user_id'];
$stmt = $conn->prepare('SELECT * FROM buses WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $busId);
$stmt->execute();
$bus = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$bus) {
    exit('Bus not found.');
}

if (isDepartureExpired($bus['departure_date'] ?? '', $bus['departure_time'] ?? '')) {
    exit('This bus departure time has already passed.');
}

function getBookedSeats(mysqli $conn, int $busId): array
{
    $taken = [];
    $stmt = $conn->prepare("SELECT seat_numbers FROM bookings WHERE bus_id = ? AND status <> 'Cancelled'");
    $stmt->bind_param('i', $busId);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $numbers = array_filter(array_map('trim', explode(',', (string) $row['seat_numbers'])));
        foreach ($numbers as $number) {
            $taken[] = $number;
        }
    }

    $stmt->close();
    return array_values(array_unique($taken));
}

$totalSeats = max(1, (int) ($bus['total_seats'] ?? $bus['seats_available'] ?? 1));
$bookedSeats = getBookedSeats($conn, $busId);
$error = '';
$successBooking = null;
$selectedSeatsMap = [];
$defaultBackUrl = 'search.php?from=' . urlencode((string) $bus['source']) . '&to=' . urlencode((string) $bus['destination']) . '&date=' . urlencode((string) $bus['departure_date']);
$backUrl = getSmoothBackUrl($defaultBackUrl);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $passengerName = trim($_POST['passenger_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $selectedSeats = $_POST['seats'] ?? [];
    $selectedSeats = array_values(array_unique(array_filter(array_map('trim', $selectedSeats), static fn($seat) => $seat !== '')));
    $selectedSeatsMap = array_fill_keys(array_map('strval', $selectedSeats), true);

    if ($passengerName === '' || $phone === '') {
        $error = 'Please enter passenger name and phone number.';
    } elseif (empty($selectedSeats)) {
        $error = 'Please select at least one seat.';
    } elseif (count(array_intersect($selectedSeats, $bookedSeats)) > 0) {
        $error = 'One or more selected seats were just booked by someone else. Please choose again.';
    } else {
        $seatCount = count($selectedSeats);
        $ticketNumber = generateTicketNumber();
        $seatNumbers = implode(',', $selectedSeats);
        $totalAmount = round((float) $bus['price'] * $seatCount, 2);

        $conn->begin_transaction();

        try {
            $update = $conn->prepare(
                'UPDATE buses SET seats_available = seats_available - ? WHERE id = ? AND seats_available >= ?'
            );
            $update->bind_param('iii', $seatCount, $busId, $seatCount);
            $update->execute();

            if ($update->affected_rows !== 1) {
                throw new RuntimeException('Not enough seats available for this booking.');
            }
            $update->close();

            $insert = $conn->prepare(
                "INSERT INTO bookings
                (user_id, bus_id, seats, total_amount, seat_numbers, passenger_name, phone, ticket_number, status, payment_status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Booked', 'Unpaid', NOW())"
            );
            $insert->bind_param(
                'iiidssss',
                $userId,
                $busId,
                $seatCount,
                $totalAmount,
                $seatNumbers,
                $passengerName,
                $phone,
                $ticketNumber
            );
            $insert->execute();

            $bookingId = (int) $insert->insert_id;
            $insert->close();

            if ($bookingId <= 0) {
                throw new RuntimeException('Booking failed. Try again.');
            }

            upsertBookingPaymentRecord($conn, $bookingId, $userId, $totalAmount, 'Pending', 0.0, null, null, false);

            $conn->commit();

            $successBooking = [
                'id' => $bookingId,
                'ticket_number' => $ticketNumber,
                'passenger_name' => $passengerName,
                'phone' => $phone,
                'seat_numbers' => $seatNumbers,
                'total' => $totalAmount,
            ];

            $bookedSeats = getBookedSeats($conn, $busId);
            $bus['seats_available'] = max(0, (int) $bus['seats_available'] - $seatCount);
            $selectedSeatsMap = [];
        } catch (Throwable $e) {
            $conn->rollback();
            $error = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Book Bus | YatraSathi</title>
<style>
html{scroll-behavior:smooth}
body{margin:0;font-family:Arial,sans-serif;background:linear-gradient(180deg,#eef4ff 0%,#f8fbff 100%);color:#17324c}
.page{max-width:1040px;margin:0 auto;padding:28px 18px 40px}
.wrap{display:grid;grid-template-columns:.95fr 1.15fr;gap:20px}
.panel{background:#fff;border-radius:20px;padding:22px;box-shadow:0 12px 30px rgba(17,55,95,.08);animation:fadeUp .35s ease}
h1,h2,h3{margin:0 0 12px}
p{line-height:1.55}
.route{font-size:1.1rem;font-weight:700}
.meta{color:#5d7287}
.notice{padding:14px 16px;border-radius:14px;margin-bottom:16px}
.error{background:#fff1f1;color:#b42318;border:1px solid #f7c2c2}
.success{background:#ecfff0;color:#116329;border:1px solid #bfe8c6}
.summary{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:18px}
.summary-item{padding:14px;border-radius:14px;background:#f8fbff;border:1px solid #dce7f4}
.summary-item strong{display:block;margin-bottom:6px;color:#0f4c81}
.form-group{margin-bottom:14px}
label{display:block;margin-bottom:6px;font-weight:700}
input[type="text"],input[type="tel"]{width:100%;padding:12px 14px;border:1px solid #c5d5e7;border-radius:12px;box-sizing:border-box}
.seat-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
.seat{position:relative}
.seat input{display:none}
.seat span{display:flex;justify-content:center;align-items:center;min-height:46px;border:1px solid #c5d5e7;border-radius:12px;font-weight:700;background:#f8fbff;cursor:pointer;transition:transform .2s ease,box-shadow .2s ease,background .2s ease,border-color .2s ease}
.seat:not(.booked) span:hover{transform:translateY(-1px);box-shadow:0 10px 18px rgba(17,55,95,.08)}
.seat input:checked + span{background:#1f6fd6;color:#fff;border-color:#1f6fd6}
.seat.booked span{background:#ffd9d9;border-color:#f0a4a4;color:#9c2b2b;cursor:not-allowed}
.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:16px}
.btn{display:inline-flex;justify-content:center;align-items:center;padding:13px 16px;border:none;border-radius:12px;font-weight:700;cursor:pointer;text-decoration:none}
.primary{background:#1f6fd6;color:#fff}
.secondary{background:#edf4ff;color:#1f6fd6}
.helper{margin-top:14px;padding:14px 16px;border-radius:14px;background:#f8fbff;border:1px solid #dce7f4;color:#4f6477}
.helper strong{color:#0f4c81}
@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
@media (max-width: 860px){.wrap{grid-template-columns:1fr}}
@media (max-width: 560px){.seat-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.page{padding:22px 14px 32px}.summary{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="page">
    <div class="actions" style="margin-bottom:16px">
        <a class="btn secondary js-back-link" href="<?= htmlspecialchars($backUrl) ?>">Back</a>
        <a class="btn secondary" href="my_bookings.php">My Bookings</a>
    </div>

    <?php if ($error !== ''): ?>
        <div class="notice error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="wrap">
        <div class="panel">
            <h1><?= htmlspecialchars($bus['bus_name']) ?></h1>
            <p class="route"><?= htmlspecialchars($bus['source']) ?> to <?= htmlspecialchars($bus['destination']) ?></p>
            <p class="meta">Departure: <?= htmlspecialchars($bus['departure_date']) ?> at <?= htmlspecialchars(formatDepartureTime($bus['departure_time'])) ?></p>
            <p class="meta">Available seats: <?= (int) $bus['seats_available'] ?></p>
            <p class="meta">Price per seat: Rs. <?= number_format((float) $bus['price'], 2) ?></p>

            <div class="summary">
                <div class="summary-item">
                    <strong>Selected seats</strong>
                    <span id="selectedSeatPreview">Choose seats to continue</span>
                </div>
                <div class="summary-item">
                    <strong>Estimated total</strong>
                    <span id="selectedSeatTotal">Rs. 0.00</span>
                </div>
            </div>

            <?php if ($successBooking): ?>
                <div class="notice success" style="margin-top:18px">
                    <h3>Booking confirmed</h3>
                    <p><strong>Passenger:</strong> <?= htmlspecialchars($successBooking['passenger_name']) ?></p>
                    <p><strong>Phone:</strong> <?= htmlspecialchars($successBooking['phone']) ?></p>
                    <p><strong>Seats:</strong> <?= htmlspecialchars($successBooking['seat_numbers']) ?></p>
                    <p><strong>Ticket Number:</strong> <?= htmlspecialchars($successBooking['ticket_number']) ?></p>
                    <p><strong>Total:</strong> Rs. <?= number_format((float) $successBooking['total'], 2) ?></p>
                </div>
                <div class="actions">
                    <a class="btn primary" href="payment.php?booking_id=<?= (int) $successBooking['id'] ?>">Pay Now</a>
                    <a class="btn secondary" href="my_bookings.php">View My Bookings</a>
                </div>
            <?php else: ?>
                <p class="meta" style="margin-top:18px">Booked seats are marked in red. Select your seats, enter passenger details, and we will carry everything to payment immediately after booking.</p>
            <?php endif; ?>
        </div>

        <div class="panel">
            <?php if (!$successBooking): ?>
                <form method="POST">
                    <input type="hidden" name="bus_id" value="<?= $busId ?>">
                    <div class="form-group">
                        <label>Select Seats</label>
                        <div class="seat-grid">
                            <?php for ($seat = 1; $seat <= $totalSeats; $seat++): ?>
                                <?php $disabled = in_array((string) $seat, $bookedSeats, true); ?>
                                <label class="seat <?= $disabled ? 'booked' : '' ?>">
                                    <input type="checkbox" name="seats[]" value="<?= $seat ?>" <?= $disabled ? 'disabled' : '' ?> <?= (!$disabled && !empty($selectedSeatsMap[(string) $seat])) ? 'checked' : '' ?>>
                                    <span><?= $seat ?></span>
                                </label>
                            <?php endfor; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="passenger_name">Passenger Name</label>
                        <input type="text" id="passenger_name" name="passenger_name" value="<?= htmlspecialchars($_POST['passenger_name'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required>
                    </div>

                  

                    <button class="btn primary" type="submit">Confirm Booking</button>
                </form>
            <?php else: ?>
                <h2>Next step</h2>
                <p class="meta">Your booking is saved with an unpaid status until payment is completed. You can pay now or later from My Bookings.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
const seatCheckboxes = Array.from(document.querySelectorAll('input[name="seats[]"]'));
const seatPreview = document.getElementById('selectedSeatPreview');
const seatTotal = document.getElementById('selectedSeatTotal');
const pricePerSeat = <?= json_encode((float) $bus['price']) ?>;

function updateSeatSummary() {
    if (!seatPreview || !seatTotal) {
        return;
    }

    const selected = seatCheckboxes.filter((input) => input.checked).map((input) => input.value);
    seatPreview.textContent = selected.length ? selected.join(', ') : 'Choose seats to continue';
    seatTotal.textContent = `Rs. ${(selected.length * pricePerSeat).toFixed(2)}`;
}

seatCheckboxes.forEach((checkbox) => {
    checkbox.addEventListener('change', updateSeatSummary);
});

document.querySelectorAll('.js-back-link').forEach((link) => {
    link.addEventListener('click', (event) => {
        if (window.history.length > 1 && document.referrer) {
            event.preventDefault();
            window.history.back();
        }
    });
});

updateSeatSummary();
</script>
</body>
</html>
