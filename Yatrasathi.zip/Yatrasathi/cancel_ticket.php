<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    redirectTo('login.php');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectTo('my_bookings.php');
}

$bookingId = (int) ($_POST['booking_id'] ?? 0);

if ($bookingId <= 0) {
    redirectTo('my_bookings.php');
}

$stmt = $conn->prepare('SELECT id, bus_id, seats, total_amount, status, payment_status, payment_method, payment_reference
                        FROM bookings 
                        WHERE id = ? AND user_id = ? 
                        LIMIT 1');
$stmt->bind_param('ii', $bookingId, $_SESSION['user_id']);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking || $booking['status'] === 'Cancelled') {
    redirectTo('my_bookings.php');
}

$conn->begin_transaction();

try {

    // Check if already paid
    if ($booking['payment_status'] === 'Paid') {
        $_SESSION['flash_msg'] = "⚠ Amount already paid will NOT be refunded.";
    }

    // Cancel booking
    $updateBooking = $conn->prepare(
        "UPDATE bookings 
         SET status = 'Cancelled', cancelled_at = NOW() 
         WHERE id = ? AND user_id = ?"
    );
    $updateBooking->bind_param('ii', $bookingId, $_SESSION['user_id']);
    $updateBooking->execute();
    $updateBooking->close();

    $paymentStatus = $booking['payment_status'] === 'Paid' ? 'Paid' : 'Cancelled';
    $paidAmount = $booking['payment_status'] === 'Paid' ? calculateBookingTotal($booking) : 0.0;
    upsertBookingPaymentRecord(
        $conn,
        (int) $booking['id'],
        (int) $_SESSION['user_id'],
        calculateBookingTotal($booking),
        $paymentStatus,
        $paidAmount,
        $booking['payment_method'] ?? null,
        $booking['payment_reference'] ?? null,
        $booking['payment_status'] === 'Paid'
    );

    // Restore seats
    $restoreSeats = $conn->prepare(
        "UPDATE buses 
         SET seats_available = seats_available + ? 
         WHERE id = ?"
    );
    $restoreSeats->bind_param('ii', $booking['seats'], $booking['bus_id']);
    $restoreSeats->execute();
    $restoreSeats->close();

    $conn->commit();

} catch (Throwable $e) {
    $conn->rollback();
    $_SESSION['flash_msg'] = "Something went wrong while cancelling ticket.";
}

redirectTo('my_bookings.php');
