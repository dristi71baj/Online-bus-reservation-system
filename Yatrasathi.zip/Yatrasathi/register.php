<?php
require_once 'config.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: " . (($_SESSION['role'] ?? '') === 'admin' ? 'admin_dashboard.php' : 'index.php'));
    exit;
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die("Invalid CSRF token");
    }

    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (!$name || !$email || !$password || !$confirm) {
        $error = "All fields are required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Email already registered";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $insert = $conn->prepare(
                "INSERT INTO users (name, email, password) VALUES (?, ?, ?)"
            );
            $insert->bind_param("sss", $name, $email, $hashedPassword);

            if ($insert->execute()) {
                $success = "Registration successful. You can now login.";
            } else {
                $error = "Something went wrong. Try again.";
            }
            $insert->close();
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register | YatraSathi</title>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
*{margin:0;padding:0;box-sizing:border-box}
body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(120deg,#1f6fd6,#6fb1ff);
    font-family:Arial;
}
.register-box{
    width:90%;
    max-width:420px;
    background:#fff;
    padding:25px;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,0.2);
}
h2{text-align:center;color:#1f6fd6;margin-bottom:20px}
input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:6px;
    border:1px solid #ccc;
}
.input-group{position:relative}
.input-group i{
    position:absolute;
    right:12px;
    top:50%;
    transform:translateY(-50%);
    cursor:pointer;
    color:#666;
}
button{
    width:100%;
    padding:12px;
    background:#1f6fd6;
    color:#fff;
    border:none;
    border-radius:6px;
    font-size:16px;
    cursor:pointer;
}
button:hover{background:#1557a6}
.error{background:#ffe0e0;color:#b00020;padding:10px;border-radius:6px;margin-bottom:10px;text-align:center}
.success{background:#e0ffe5;color:#006400;padding:10px;border-radius:6px;margin-bottom:10px;text-align:center}
.link{text-align:center;margin-top:15px}
.link a{color:#1f6fd6;text-decoration:none}

@media(max-width:480px){
    .register-box{padding:20px}
    h2{font-size:20px}
    input,button{font-size:14px;padding:10px}
}
</style>
</head>

<body>
<div class="register-box">
<h2>Create Account</h2>

<?php if ($error): ?>
<div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($success): ?>
<div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="post">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

<input type="text" name="name" placeholder="Full Name" required>
<input type="email" name="email" placeholder="Email Address" required>

<div class="input-group">
<input type="password" id="password" name="password" placeholder="Password" required>
<i class="fa-solid fa-eye" onclick="togglePassword('password',this)"></i>
</div>

<div class="input-group">
<input type="password" id="confirm" name="confirm_password" placeholder="Confirm Password" required>
<i class="fa-solid fa-eye" onclick="togglePassword('confirm',this)"></i>
</div>

<button type="submit">Register</button>
</form>

<div class="link">
Already have an account? <a href="login.php">Login</a>
</div>
</div>

<script>
function togglePassword(id,icon){
    const input=document.getElementById(id);
    if(input.type==='password'){
        input.type='text';
        icon.classList.replace('fa-eye','fa-eye-slash');
    }else{
        input.type='password';
        icon.classList.replace('fa-eye-slash','fa-eye');
    }
}
</script>

</body>
</html>
